import re
import random
from typing import Dict, List

class TextCleaner:
    def __init__(self):
        # Define replacement rules with multiple options
        self.replacements = {
            "bias": ["optimize"],
            "control": ["manage"],
            "leverage": ["optimize", "utilize"],
            "market": ["region", "country", "corporate travel industry", "corporate travel business"],
            "power": ["skill", "value", "efficiency", "capability"],
            "revenue synergy": ["cost synergy", "efficiencies"],
            "target": ["target", "goal"],
            "pinpoint": ["pinpoint"],
            "expert": ["professional", "specialist", "counselor", "experience"],
            "expertise": ["professional", "specialist", "counselor", "experience"],
            "subject-matter expert": ["professional", "specialist", "counselor", "experience"]
        }
        
        # Define banned words
        self.banned_words = ["ensure", "insure", "guarantee"]
    
    def clean_text(self, input_text: str) -> str:
        """Clean text by removing banned words and replacing restricted words"""
        cleaned = input_text

        # Remove banned words
        for banned in self.banned_words:
            cleaned = re.sub(rf"(?i)\b{banned}\b", "", cleaned)

        # Replace restricted words with a random alternative
        for word, alternatives in self.replacements.items():
            cleaned = re.sub(
                rf"(?i)\b{word}\b", 
                lambda match: random.choice(alternatives), 
                cleaned
            )

        return cleaned
    
    def clean_csv_content(self, content: str) -> str:
        """Clean CSV content by removing non-CSV elements"""
        # Remove any non-CSV content
        lines = content.strip().split('\n')
        csv_lines = []
        
        for line in lines:
            if line.strip() and not line.startswith('```'):
                csv_lines.append(line)
        
        return '\n'.join(csv_lines)
    
    def validate_csv_structure(self, csv_content: str, expected_columns: List[str]) -> bool:
        """Validate CSV structure has expected columns"""
        lines = csv_content.strip().split('\n')
        if not lines:
            return False
        
        # Check header
        header = lines[0].split(',')
        header = [col.strip().strip('"') for col in header]
        
        return header == expected_columns
    
    def fix_csv_quotes(self, content: str) -> str:
        """Fix CSV quotes to prevent parsing issues"""
        lines = content.split('\n')
        fixed_lines = []
        
        for line in lines:
            if line.strip():
                # Handle fields that contain commas
                fields = line.split(',')
                fixed_fields = []
                
                for field in fields:
                    field = field.strip()
                    if ',' in field and not (field.startswith('"') and field.endswith('"')):
                        field = f'"{field}"'
                    elif field.startswith('"') and not field.endswith('"'):
                        field = f'{field}"'
                    elif field.endswith('"') and not field.startswith('"'):
                        field = f'"{field}'
                    
                    fixed_fields.append(field)
                
                fixed_lines.append(','.join(fixed_fields))
        
        return '\n'.join(fixed_lines)
    
    def extract_csv_from_response(self, response_text: str) -> str:
        """Extract CSV content from API response"""
        # Look for CSV content between markdown code blocks
        csv_match = re.search(r'```(?:csv)?\s*\n(.*?)\n```', response_text, re.DOTALL)
        if csv_match:
            return csv_match.group(1).strip()
        
        # If no code blocks, look for CSV-like content
        lines = response_text.split('\n')
        csv_lines = []
        in_csv = False
        
        for line in lines:
            if ',' in line and any(col.strip() for col in line.split(',')):
                in_csv = True
                csv_lines.append(line)
            elif in_csv and line.strip():
                csv_lines.append(line)
            elif in_csv and not line.strip():
                break
        
        return '\n'.join(csv_lines) 