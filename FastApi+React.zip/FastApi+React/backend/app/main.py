from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os

from app.routes import upload, analysis, files, summary

app = FastAPI(
    title="Travel Policy Analysis API",
    description="AI-powered travel policy analysis and gap analysis tool",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create necessary directories
os.makedirs("uploads", exist_ok=True)
os.makedirs("Outputs", exist_ok=True)
os.makedirs("input", exist_ok=True)
os.makedirs("gapfilled", exist_ok=True)
os.makedirs("output", exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Include routers
app.include_router(upload.router, prefix="/api/upload", tags=["upload"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["analysis"])
app.include_router(files.router, prefix="/api/files", tags=["files"])
app.include_router(summary.router, prefix="/api/summary", tags=["summary"])

@app.get("/")
async def root():
    return {"message": "Travel Policy Analysis API is running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"} 