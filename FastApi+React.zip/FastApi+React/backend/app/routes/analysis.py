from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
import os
import pandas as pd
from app.services.gap_analysis import GapAnalysisService

router = APIRouter()

@router.post("/gap-analysis")
async def run_gap_analysis(background_tasks: BackgroundTasks):
    """Run gap analysis on processed policy data"""
    try:
        # Check if processed files exist
        outputs_dir = "Outputs"
        if not os.path.exists(outputs_dir) or not os.listdir(outputs_dir):
            raise HTTPException(status_code=400, detail="No processed files found. Please upload and process a PDF first.")
        
        # Run gap analysis in background
        background_tasks.add_task(process_gap_analysis)
        
        return JSONResponse({
            "message": "Gap analysis started",
            "status": "processing"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def process_gap_analysis():
    """Background task to process gap analysis"""
    try:
        gap_service = GapAnalysisService()
        await gap_service.run_analysis()
        
    except Exception as e:
        print(f"Error in gap analysis: {e}")

@router.get("/gap-analysis/status")
async def get_gap_analysis_status():
    """Get the status of gap analysis processing"""
    gapfilled_dir = "gapfilled"
    
    if os.path.exists(gapfilled_dir) and os.listdir(gapfilled_dir):
        files = [f for f in os.listdir(gapfilled_dir) if f.endswith('.csv')]
        return {
            "status": "completed",
            "files": files,
            "count": len(files)
        }
    else:
        return {"status": "processing"}

@router.get("/gap-analysis/files")
async def list_gap_analysis_files():
    """List all gap analysis output files"""
    gapfilled_dir = "gapfilled"
    
    if not os.path.exists(gapfilled_dir):
        return {"files": []}
    
    files = []
    for filename in os.listdir(gapfilled_dir):
        if filename.endswith('.csv'):
            file_path = os.path.join(gapfilled_dir, filename)
            file_size = os.path.getsize(file_path)
            files.append({
                "filename": filename,
                "size": file_size,
                "path": file_path
            })
    
    return {"files": files}

@router.get("/gap-analysis/file/{filename}")
async def get_gap_analysis_file(filename: str):
    """Get content of a specific gap analysis file"""
    file_path = f"gapfilled/{filename}"
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    try:
        df = pd.read_csv(file_path)
        return {
            "filename": filename,
            "data": df.to_dict('records'),
            "columns": df.columns.tolist(),
            "row_count": len(df)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}") 