from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
import os
import aiofiles
import asyncio
from typing import List
import pandas as pd
from app.services.policy_extraction import PolicyExtractionService
from app.services.pdf_processor import PDFProcessor

router = APIRouter()

@router.post("/pdf")
async def upload_pdf(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...)
):
    """Upload PDF travel policy document"""
    if not file.filename.endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are allowed")
    
    # Save uploaded file
    upload_path = f"uploads/{file.filename}"
    async with aiofiles.open(upload_path, 'wb') as f:
        content = await file.read()
        await f.write(content)
    
    # Process PDF in background
    background_tasks.add_task(process_pdf_extraction, upload_path)
    
    return JSONResponse({
        "message": "PDF uploaded successfully",
        "filename": file.filename,
        "status": "processing"
    })

@router.post("/template")
async def upload_template(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...)
):
    """Upload Excel template file"""
    if not file.filename.endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Only Excel files are allowed")
    
    # Save uploaded file
    upload_path = f"input/{file.filename}"
    async with aiofiles.open(upload_path, 'wb') as f:
        content = await file.read()
        await f.write(content)
    
    return JSONResponse({
        "message": "Template uploaded successfully",
        "filename": file.filename
    })

async def process_pdf_extraction(pdf_path: str):
    """Background task to process PDF extraction"""
    try:
        pdf_processor = PDFProcessor()
        pdf_text = await pdf_processor.extract_text(pdf_path)
        
        # Initialize policy extraction service
        extraction_service = PolicyExtractionService()
        
        # Process the PDF text
        await extraction_service.process_policy(pdf_text, pdf_path)
        
    except Exception as e:
        print(f"Error processing PDF: {e}")

@router.get("/status/{filename}")
async def get_processing_status(filename: str):
    """Get the processing status of an uploaded file"""
    output_path = f"Outputs/{filename.replace('.pdf', '_processed.csv')}"
    
    if os.path.exists(output_path):
        return {"status": "completed", "output_file": output_path}
    else:
        return {"status": "processing"} 