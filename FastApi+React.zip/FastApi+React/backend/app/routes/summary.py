from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
import os
from app.services.summary_generator import SummaryGenerator

router = APIRouter()

@router.post("/generate")
async def generate_summary(background_tasks: BackgroundTasks):
    """Generate gap summary report"""
    try:
        # Check if gap analysis files exist
        gapfilled_dir = "gapfilled"
        if not os.path.exists(gapfilled_dir) or not os.listdir(gapfilled_dir):
            raise HTTPException(
                status_code=400, 
                detail="No gap analysis files found. Please run gap analysis first."
            )
        
        # Generate summary in background
        background_tasks.add_task(process_summary_generation)
        
        return JSONResponse({
            "message": "Summary generation started",
            "status": "processing"
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

async def process_summary_generation():
    """Background task to generate summary"""
    try:
        summary_generator = SummaryGenerator()
        await summary_generator.generate_summary()
        
    except Exception as e:
        print(f"Error generating summary: {e}")

@router.get("/status")
async def get_summary_status():
    """Get the status of summary generation"""
    output_path = "output/Gap_Summary.docx"
    
    if os.path.exists(output_path):
        file_size = os.path.getsize(output_path)
        return {
            "status": "completed",
            "filename": "Gap_Summary.docx",
            "size": file_size,
            "path": output_path
        }
    else:
        return {"status": "processing"}

@router.get("/download")
async def download_summary():
    """Download the generated summary report"""
    output_path = "output/Gap_Summary.docx"
    
    if not os.path.exists(output_path):
        raise HTTPException(status_code=404, detail="Summary report not found")
    
    return FileResponse(
        path=output_path,
        filename="Gap_Summary.docx",
        media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )

@router.get("/preview")
async def preview_summary():
    """Get a preview of the summary content"""
    output_path = "output/Gap_Summary.docx"
    
    if not os.path.exists(output_path):
        raise HTTPException(status_code=404, detail="Summary report not found")
    
    try:
        from docx import Document
        
        doc = Document(output_path)
        content = []
        
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                content.append(paragraph.text)
        
        return {
            "filename": "Gap_Summary.docx",
            "content": content,
            "paragraph_count": len(content)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading summary: {str(e)}") 