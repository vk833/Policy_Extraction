from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, JSONResponse
import os
import zipfile
import io
from typing import List

router = APIRouter()

@router.get("/list")
async def list_files():
    """List all available files in different directories"""
    try:
        files_data = {}
        
        # List files from different directories
        directories = {
            "uploads": "uploads",
            "outputs": "Outputs", 
            "gapfilled": "gapfilled",
            "input": "input"
        }
        
        for dir_name, dir_path in directories.items():
            if os.path.exists(dir_path):
                files = []
                for filename in os.listdir(dir_path):
                    file_path = os.path.join(dir_path, filename)
                    if os.path.isfile(file_path):
                        file_size = os.path.getsize(file_path)
                        files.append({
                            "filename": filename,
                            "size": file_size,
                            "path": file_path
                        })
                files_data[dir_name] = files
            else:
                files_data[dir_name] = []
        
        return files_data
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/download/{directory}/{filename}")
async def download_file(directory: str, filename: str):
    """Download a specific file"""
    valid_directories = ["uploads", "Outputs", "gapfilled", "input"]
    
    if directory not in valid_directories:
        raise HTTPException(status_code=400, detail="Invalid directory")
    
    file_path = f"{directory}/{filename}"
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type='application/octet-stream'
    )

@router.get("/download-all/{directory}")
async def download_all_files(directory: str):
    """Download all files from a directory as a zip file"""
    valid_directories = ["Outputs", "gapfilled"]
    
    if directory not in valid_directories:
        raise HTTPException(status_code=400, detail="Invalid directory")
    
    if not os.path.exists(directory):
        raise HTTPException(status_code=404, detail="Directory not found")
    
    # Create zip file in memory
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            if os.path.isfile(file_path):
                zip_file.write(file_path, filename)
    
    zip_buffer.seek(0)
    
    return FileResponse(
        io.BytesIO(zip_buffer.getvalue()),
        media_type='application/zip',
        filename=f"{directory}_files.zip"
    )

@router.delete("/delete/{directory}/{filename}")
async def delete_file(directory: str, filename: str):
    """Delete a specific file"""
    valid_directories = ["uploads", "Outputs", "gapfilled", "input"]
    
    if directory not in valid_directories:
        raise HTTPException(status_code=400, detail="Invalid directory")
    
    file_path = f"{directory}/{filename}"
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    try:
        os.remove(file_path)
        return JSONResponse({
            "message": f"File {filename} deleted successfully"
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error deleting file: {str(e)}")

@router.get("/view/{directory}/{filename}")
async def view_file_content(directory: str, filename: str):
    """View content of a CSV file"""
    valid_directories = ["Outputs", "gapfilled"]
    
    if directory not in valid_directories:
        raise HTTPException(status_code=400, detail="Invalid directory")
    
    file_path = f"{directory}/{filename}"
    
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    if not filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files can be viewed")
    
    try:
        import pandas as pd
        df = pd.read_csv(file_path)
        
        return {
            "filename": filename,
            "data": df.to_dict('records'),
            "columns": df.columns.tolist(),
            "row_count": len(df)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading file: {str(e)}") 