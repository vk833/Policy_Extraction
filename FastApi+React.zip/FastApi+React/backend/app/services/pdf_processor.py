import pdfplumber
import re
import asyncio
from typing import List

class PDFProcessor:
    def __init__(self):
        self.band_height = 100
        self.overlap = 30
    
    async def extract_text(self, pdf_path: str) -> str:
        """Extract text from PDF with column detection"""
        try:
            # Run PDF processing in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            text = await loop.run_in_executor(None, self._extract_text_sync, pdf_path)
            return text
        except Exception as e:
            raise Exception(f"Error extracting text from PDF: {str(e)}")
    
    def _extract_text_sync(self, pdf_path: str) -> str:
        """Synchronous PDF text extraction"""
        extracted_text = ""
        
        with pdfplumber.open(pdf_path) as pdf:
            for page_num, page in enumerate(pdf.pages, start=1):
                extracted_text += f"\n--- Page {page_num} ---\n"
                page_width = page.width
                page_height = page.height
                mid_x = page_width / 2

                y_top = 0
                while y_top < page_height:
                    y_bottom = min(y_top + self.band_height, page_height)
                    band = page.within_bbox((0, y_top, page_width, y_bottom))
                    chars = band.chars

                    if self._is_two_column_band(chars, mid_x):
                        left_text = page.within_bbox((0, y_top, mid_x, y_bottom)).extract_text() or ""
                        right_text = page.within_bbox((mid_x, y_top, page_width, y_bottom)).extract_text() or ""
                        extracted_text += left_text + "\n" + right_text + "\n"
                    else:
                        full_text = band.extract_text() or ""
                        extracted_text += full_text + "\n"

                    y_top += self.band_height - self.overlap

        return extracted_text
    
    def _is_two_column_band(self, chars: List, mid_x: float, threshold: float = 0.2) -> bool:
        """Check if a band of text is in two columns"""
        if not chars:
            return False
        
        left_count = sum(1 for c in chars if c["x0"] < mid_x)
        right_count = sum(1 for c in chars if c["x0"] >= mid_x)
        
        if max(left_count, right_count) == 0:
            return False
        
        return min(left_count, right_count) / max(left_count, right_count) > threshold
    
    def clean_text(self, text: str) -> str:
        """Clean extracted text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove page markers
        text = re.sub(r'--- Page \d+ ---', '', text)
        
        # Clean up line breaks
        text = re.sub(r'\n\s*\n', '\n\n', text)
        
        return text.strip() 