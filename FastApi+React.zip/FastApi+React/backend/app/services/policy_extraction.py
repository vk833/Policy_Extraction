import aiohttp
import asyncio
import pandas as pd
import os
import re
import random
from typing import Dict, List
from app.utils.text_cleaner import TextCleaner

class PolicyExtractionService:
    def __init__(self):
        self.api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/c5f9ae69-685e-48f1-9958-5d44b5b92557/conversation"
        self.headers = self._get_headers()
        self.text_cleaner = TextCleaner()
        
        # Define categories for processing
        self.categories = [
            "Air Travel", "Expense Management", "Ground Transportation",
            "Group & Events Travel", "Hotel Lodging", "Meals & Entertainment",
            "Overview & Guidelines", "Risk Management", "Sustainability&Wellbeing",
            "Travel Arrangements"
        ]
    
    def _get_headers(self) -> Dict[str, str]:
        """Get API headers with authentication token"""
        try:
            import requests
            token_response = requests.post(
                "https://amexgbt.okta.com/oauth2/default/v1/token",
                headers={
                    "Authorization": "Basic MG9hMjJ3NHFqMWtyU3dPUDEwaDg6Q2t0cGZYS0RPdmprM1lDdVBmTVp0UkgtajhKMEs4Z1JWRy1mT2dQaG5Pb2ZJVE9lbldiY05BXy00cXhna1hkWQ==",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data="grant_type=client_credentials",
            )
            
            if token_response.status_code == 200:
                token = token_response.json().get("access_token")
                return {
                    'Content-Type': 'application/json',
                    'X-Access-Token': token
                }
            else:
                raise Exception("Failed to get authentication token")
                
        except Exception as e:
            raise Exception(f"Authentication failed: {str(e)}")
    
    async def process_policy(self, pdf_text: str, pdf_path: str):
        """Process policy document and generate CSV files"""
        try:
            # Get template data
            template_data = await self._get_template_data()
            
            # Process each category
            tasks = []
            async with aiohttp.ClientSession() as session:
                for category in self.categories:
                    task = self._process_category(
                        session, category, pdf_text, template_data
                    )
                    tasks.append(task)
                
                # Wait for all categories to complete
                results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Save results
            await self._save_results(results)
            
        except Exception as e:
            raise Exception(f"Error processing policy: {str(e)}")
    
    async def _get_template_data(self) -> str:
        """Get template data from input directory"""
        template_path = "input/Template.xlsx"
        
        if not os.path.exists(template_path):
            # Use default template structure
            return self._get_default_template()
        
        try:
            df = pd.read_excel(template_path)
            return df.to_string()
        except Exception as e:
            print(f"Error reading template: {e}")
            return self._get_default_template()
    
    def _get_default_template(self) -> str:
        """Get default template structure"""
        return """
        Category,Subcategory,Primary Content,Type,Client Content,Rating,Points,Maximum Score,GBC BEST PRACTICE CONTENT
        Air Travel,Booking,Air travel booking requirements,Policy,,,0,0,
        Air Travel,Class of Travel,Class of travel restrictions,Policy,,,0,0,
        Expense Management,Reimbursement,Expense reimbursement process,Policy,,,0,0,
        """
    
    async def _process_category(
        self, 
        session: aiohttp.ClientSession, 
        category: str, 
        pdf_text: str, 
        template_data: str
    ) -> Dict:
        """Process a single category"""
        try:
            # Clean text
            cleaned_pdf_text = self.text_cleaner.clean_text(pdf_text)
            
            # Prepare prompt
            prompt = self._create_prompt(category, cleaned_pdf_text, template_data)
            
            # Make API call
            data = {
                "promptId": "58fc18e0-2ee3-46da-841e-2f494ffe2ce5",
                "messages": [],
                "input": {"input": prompt},
            }
            
            async with session.post(
                self.api_url, 
                headers=self.headers, 
                json=data, 
                ssl=False
            ) as resp:
                resp.raise_for_status()
                response_json = await resp.json()
                
                csv_content = response_json["data"]["messages"][0]["content"]
                
                return {
                    "category": category,
                    "content": csv_content,
                    "status": "success"
                }
                
        except Exception as e:
            return {
                "category": category,
                "content": "",
                "status": "error",
                "error": str(e)
            }
    
    def _create_prompt(self, category: str, pdf_text: str, template_data: str) -> str:
        """Create the prompt for API call"""
        return f"""
        This is a travel policy document (PDF1): {pdf_text}
        This is an Excel file (Excel1): {template_data}

        Task: Process the category '{category}'.

        MANDATORY INSTRUCTIONS:
        - Do NOT skip any rows of category:{category}.
        - Process ALL entries for this category. 
        - Output MUST be a valid CSV with the following columns in this exact order:
        "Category", "Subcategory", "Primary Content", "Type", "Client Content", "Rating", "Points", "Maximum Score", "GBC BEST PRACTICE CONTENT"
        - Every row MUST contain values for "Category" and "Subcategory":
        - If missing, use the current category name for "Category".
        - Infer "Subcategory" from context or leave as "General" if not available.
        - DO NOT allow any column displacement. Each value must stay in its correct column.
        - If any column contains commas, quotes, or line breaks, wrap the entire field in double quotes to preserve CSV structure.
        - Fix malformed rows caused by broken lines or misplaced commas.
        - DO NOT merge or duplicate columns.
        - DO NOT copy "GBC BEST PRACTICE CONTENT" into "Client Content".
        - "Client Content" must be detailed, accurate, and based on the policy document.
        - Compare "Client Content" with "GBC BEST PRACTICE CONTENT" and assign a rating: Full, Partial, or Null.
        - If "Type" is not blank, set "Maximum Score" to 0.
        - DO NOT include any explanation or text before or after the CSV.
        - Return ONLY the CSV content, clean and ready to be saved.
        
        ADDITIONAL INSTRUCTION FOR Data Integrity:
        - Ensure the category "{category}" is fully and accurately processed.
        - Do not omit any word, column, row, content, or value from the {category} Category.
        - Every column and every row from the input Excel sheet related to this category must be included in the output.
        - Do NOT skip or omit any content from any column.
        - Each value from the input must be placed in its correct corresponding column in the output CSV.
        - Maintain the exact column structure and order as specified.
        - Do NOT merge, shift, or misplace any content across columns.
        - Pay special attention to preserving the integrity of each row's data across all columns.
        - Put GBC BEST PRACTICE CONTENT Content Into "".
        - I want 9 fields in output in all rows.

        IMPORTANT STRUCTURE VALIDATION:
        - Every row in the output MUST contain exactly 9 fields, matching the header structure.
        - If any row has fewer than 9 fields, fill missing values appropriately.
        - If any row has more than 9 fields, remove excess values or merge them correctly to maintain structure.
        - DO NOT return any malformed rows. Every row must be clean, complete, and aligned with the header.
        - Validate the CSV before returning. If any row is malformed, fix it before including it in the output.

        ADDITIONAL INSTRUCTION FOR "Client Content":
        - For each row, extract or paraphrase all relevant and specific content from the travel policy document (PDF1) that corresponds to the "Primary Content" and "Category", "Subcategory".
        - Include every applicable point from the policy. Do NOT summarize or merge multiple points into one—list them all clearly and completely.
        - Ensure "Client Content" is not generic. It must reflect the actual language, rules, or procedures stated in the policy.
        - If the policy contains multiple relevant clauses, include each one in full or paraphrased form, separated clearly.
        - Prioritize accuracy and completeness. Do not leave "Client Content" blank unless the policy has absolutely no relevant information.
        - Do NOT copy or reference "GBC BEST PRACTICE CONTENT" in this column.
        - Strictly Follow = Wrap the entire "Client Content" field in double quotes ("") to prevent column displacement due to commas, line breaks, or special characters.
        - If the information is not present in Policy so do not make or put related information just put "Not available in policy document".
        - If specific information is not explicitly mentioned in the policy document, do not infer or include related details. Instead, clearly state: 'Not available in policy document'.
        
        - Output MUST be a valid CSV with the following columns in this exact order...
        - You MUST include the CSV header line exactly as specified, even if no data rows are present.
        """
    
    async def _save_results(self, results: List[Dict]):
        """Save processing results to CSV files"""
        os.makedirs("Outputs", exist_ok=True)
        
        for result in results:
            if result["status"] == "success" and result["content"]:
                try:
                    # Clean and save CSV content
                    csv_content = self._clean_csv_content(result["content"])
                    filename = f"{result['category'].replace(' ', '_').replace('&', 'and')}.csv"
                    filepath = f"Outputs/{filename}"
                    
                    with open(filepath, 'w', newline='', encoding='utf-8') as f:
                        f.write(csv_content)
                    
                    print(f"Saved {filename}")
                    
                except Exception as e:
                    print(f"Error saving {result['category']}: {e}")
            else:
                print(f"Failed to process {result['category']}: {result.get('error', 'Unknown error')}")
    
    def _clean_csv_content(self, content: str) -> str:
        """Clean CSV content"""
        # Remove any non-CSV content
        lines = content.strip().split('\n')
        csv_lines = []
        
        for line in lines:
            if line.strip() and not line.startswith('```'):
                csv_lines.append(line)
        
        return '\n'.join(csv_lines) 