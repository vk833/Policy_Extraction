import aiohttp
import asyncio
import pandas as pd
import os
from typing import Dict, List
from docx import Document
from docx.shared import Inches
from app.utils.text_cleaner import TextCleaner

class SummaryGenerator:
    def __init__(self):
        self.api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/c5f9ae69-685e-48f1-9958-5d44b5b92557/conversation"
        self.headers = self._get_headers()
        self.text_cleaner = TextCleaner()
    
    def _get_headers(self) -> Dict[str, str]:
        """Get API headers with authentication token"""
        try:
            import requests
            token_response = requests.post(
                "https://amexgbt.okta.com/oauth2/default/v1/token",
                headers={
                    "Authorization": "Basic MG9hMjJ3NHFqMWtyU3dPUDEwaDg6Q2t0cGZYS0RPdmprM1lDdVBmTVp0UkgtajhKMEs4Z1JWRy1mT2dQaG5Pb2ZJVE9lbldiY05BXy00cXhna1hkWQ==",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data="grant_type=client_credentials",
            )
            
            if token_response.status_code == 200:
                token = token_response.json().get("access_token")
                return {
                    'Content-Type': 'application/json',
                    'X-Access-Token': token
                }
            else:
                raise Exception("Failed to get authentication token")
                
        except Exception as e:
            raise Exception(f"Authentication failed: {str(e)}")
    
    async def generate_summary(self):
        """Generate comprehensive gap summary report"""
        try:
            # Check if gap analysis files exist
            gapfilled_dir = "gapfilled"
            if not os.path.exists(gapfilled_dir):
                raise Exception("No gap analysis files found. Please run gap analysis first.")
            
            # Get all gap analysis files
            gap_files = [f for f in os.listdir(gapfilled_dir) if f.endswith('.csv')]
            if not gap_files:
                raise Exception("No gap analysis CSV files found.")
            
            # Collect all gap analysis data
            all_gap_data = await self._collect_gap_data(gapfilled_dir, gap_files)
            
            # Generate summary using AI
            summary_content = await self._generate_ai_summary(all_gap_data)
            
            # Create Word document
            await self._create_summary_document(summary_content)
            
        except Exception as e:
            raise Exception(f"Error generating summary: {str(e)}")
    
    async def _collect_gap_data(self, gapfilled_dir: str, gap_files: List[str]) -> str:
        """Collect all gap analysis data into a single string"""
        all_data = []
        
        for file in gap_files:
            try:
                file_path = os.path.join(gapfilled_dir, file)
                df = pd.read_csv(file_path)
                
                category_name = file.replace('.csv', '').replace('_', ' ')
                all_data.append(f"\n=== {category_name} ===\n")
                all_data.append(df.to_string())
                all_data.append("\n" + "="*50 + "\n")
                
            except Exception as e:
                print(f"Error reading {file}: {e}")
        
        return '\n'.join(all_data)
    
    async def _generate_ai_summary(self, gap_data: str) -> str:
        """Generate summary using AI API"""
        try:
            prompt = self._create_summary_prompt(gap_data)
            
            data = {
                "promptId": "030a86e1-ca63-4cd9-8901-27d869925bc7",
                "messages": [],
                "input": {"input": prompt},
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.api_url, 
                    headers=self.headers, 
                    json=data, 
                    ssl=False
                ) as resp:
                    resp.raise_for_status()
                    response_json = await resp.json()
                    
                    return response_json["data"]["messages"][0]["content"]
                    
        except Exception as e:
            raise Exception(f"Error generating AI summary: {str(e)}")
    
    def _create_summary_prompt(self, gap_data: str) -> str:
        """Create the prompt for summary generation"""
        return f"""
        Create a comprehensive executive summary report based on the following gap analysis data:

        {gap_data}

        Please structure the report with the following sections:

        1. Executive Summary
           - Overall assessment of the travel policy
           - Key strengths and weaknesses
           - Priority areas for improvement

        2. Gap Analysis Overview
           - Summary of gaps found across all categories
           - Risk assessment
           - Compliance implications

        3. Category-by-Category Analysis
           - Detailed findings for each travel policy category
           - Specific recommendations for each area

        4. Recommendations
           - Prioritized list of improvements
           - Implementation timeline suggestions
           - Resource requirements

        5. Risk Assessment
           - High, medium, and low-risk areas
           - Mitigation strategies
           - Compliance risks

        6. Conclusion
           - Summary of key findings
           - Next steps
           - Expected outcomes

        Please format this as a professional business report suitable for executive review.
        Use clear, concise language and provide actionable insights.
        """
    
    async def _create_summary_document(self, summary_content: str):
        """Create Word document from summary content"""
        try:
            # Create output directory
            os.makedirs("output", exist_ok=True)
            
            # Create Word document
            doc = Document()
            
            # Add title
            title = doc.add_heading('Travel Policy Gap Analysis Summary Report', 0)
            title.alignment = 1  # Center alignment
            
            # Add date
            from datetime import datetime
            date_paragraph = doc.add_paragraph(f"Generated on: {datetime.now().strftime('%B %d, %Y')}")
            date_paragraph.alignment = 1
            
            # Add content
            sections = summary_content.split('\n\n')
            
            for section in sections:
                if section.strip():
                    # Check if it's a heading
                    if section.strip().startswith(('1.', '2.', '3.', '4.', '5.', '6.')):
                        # Extract heading text
                        heading_text = section.split('\n')[0].strip()
                        if ':' in heading_text:
                            heading_text = heading_text.split(':', 1)[1].strip()
                        doc.add_heading(heading_text, level=1)
                        
                        # Add remaining content as paragraph
                        remaining_content = '\n'.join(section.split('\n')[1:]).strip()
                        if remaining_content:
                            doc.add_paragraph(remaining_content)
                    else:
                        doc.add_paragraph(section.strip())
            
            # Save document
            doc.save('output/Gap_Summary.docx')
            print("Summary document created: output/Gap_Summary.docx")
            
        except Exception as e:
            raise Exception(f"Error creating summary document: {str(e)}") 