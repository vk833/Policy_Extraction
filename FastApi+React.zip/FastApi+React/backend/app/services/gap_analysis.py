import aiohttp
import asyncio
import pandas as pd
import os
from typing import Dict, List
from app.utils.text_cleaner import TextCleaner

class GapAnalysisService:
    def __init__(self):
        self.api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/c5f9ae69-685e-48f1-9958-5d44b5b92557/conversation"
        self.headers = self._get_headers()
        self.text_cleaner = TextCleaner()
        
        # Define categories for gap analysis
        self.categories = [
            "Air_Travel", "Expense_Management", "Ground_Transportation",
            "Group_&_Events_Travel", "Hotel_Lodging", "Meals_&_Entertainment",
            "Overview_&_Guidelines", "Risk_Management", "Sustainability&Wellbeing",
            "Travel_Arrangements"
        ]
    
    def _get_headers(self) -> Dict[str, str]:
        """Get API headers with authentication token"""
        try:
            import requests
            token_response = requests.post(
                "https://amexgbt.okta.com/oauth2/default/v1/token",
                headers={
                    "Authorization": "Basic MG9hMjJ3NHFqMWtyU3dPUDEwaDg6Q2t0cGZYS0RPdmprM1lDdVBmTVp0UkgtajhKMEs4Z1JWRy1mT2dQaG5Pb2ZJVE9lbldiY05BXy00cXhna1hkWQ==",
                    "Content-Type": "application/x-www-form-urlencoded",
                },
                data="grant_type=client_credentials",
            )
            
            if token_response.status_code == 200:
                token = token_response.json().get("access_token")
                return {
                    'Content-Type': 'application/json',
                    'X-Access-Token': token
                }
            else:
                raise Exception("Failed to get authentication token")
                
        except Exception as e:
            raise Exception(f"Authentication failed: {str(e)}")
    
    async def run_analysis(self):
        """Run gap analysis on all processed policy files"""
        try:
            # Check if output files exist
            outputs_dir = "Outputs"
            if not os.path.exists(outputs_dir):
                raise Exception("No output files found. Please process a policy document first.")
            
            # Get all CSV files from outputs
            csv_files = [f for f in os.listdir(outputs_dir) if f.endswith('.csv')]
            if not csv_files:
                raise Exception("No CSV files found in outputs directory.")
            
            # Process each category
            tasks = []
            async with aiohttp.ClientSession() as session:
                for category in self.categories:
                    # Find corresponding CSV file
                    category_file = None
                    for file in csv_files:
                        if category.replace('_', ' ') in file or category in file:
                            category_file = file
                            break
                    
                    if category_file:
                        task = self._process_gap_analysis(
                            session, category, f"{outputs_dir}/{category_file}"
                        )
                        tasks.append(task)
                
                # Wait for all categories to complete
                results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Save results
            await self._save_gap_results(results)
            
        except Exception as e:
            raise Exception(f"Error running gap analysis: {str(e)}")
    
    async def _process_gap_analysis(
        self, 
        session: aiohttp.ClientSession, 
        category: str, 
        csv_file_path: str
    ) -> Dict:
        """Process gap analysis for a single category"""
        try:
            # Read CSV file
            df = pd.read_csv(csv_file_path)
            csv_content = df.to_string()
            
            # Prepare prompt for gap analysis
            prompt = self._create_gap_analysis_prompt(category, csv_content)
            
            # Make API call
            data = {
                "promptId": "030a86e1-ca63-4cd9-8901-27d869925bc7",
                "messages": [],
                "input": {"input": prompt},
            }
            
            async with session.post(
                self.api_url, 
                headers=self.headers, 
                json=data, 
                ssl=False
            ) as resp:
                resp.raise_for_status()
                response_json = await resp.json()
                
                gap_content = response_json["data"]["messages"][0]["content"]
                
                return {
                    "category": category,
                    "content": gap_content,
                    "status": "success"
                }
                
        except Exception as e:
            return {
                "category": category,
                "content": "",
                "status": "error",
                "error": str(e)
            }
    
    def _create_gap_analysis_prompt(self, category: str, csv_content: str) -> str:
        """Create the prompt for gap analysis API call"""
        return f"""
        Analyze the following travel policy data for category: {category}

        CSV Data:
        {csv_content}

        Task: Perform gap analysis and provide recommendations.

        Instructions:
        1. Analyze the current policy coverage for {category}
        2. Identify gaps in policy implementation
        3. Provide specific recommendations for improvement
        4. Rate the overall policy strength for this category
        5. Suggest best practices that are missing

        Output Format:
        - Gap Analysis Summary
        - Key Findings
        - Recommendations
        - Risk Assessment
        - Implementation Priority

        Please provide a comprehensive analysis that can be used to improve the travel policy.
        """
    
    async def _save_gap_results(self, results: List[Dict]):
        """Save gap analysis results to CSV files"""
        os.makedirs("gapfilled", exist_ok=True)
        
        for result in results:
            if result["status"] == "success" and result["content"]:
                try:
                    # Clean and save content
                    content = self._clean_gap_content(result["content"])
                    filename = f"{result['category']}.csv"
                    filepath = f"gapfilled/{filename}"
                    
                    with open(filepath, 'w', newline='', encoding='utf-8') as f:
                        f.write(content)
                    
                    print(f"Saved gap analysis: {filename}")
                    
                except Exception as e:
                    print(f"Error saving gap analysis for {result['category']}: {e}")
            else:
                print(f"Failed to process gap analysis for {result['category']}: {result.get('error', 'Unknown error')}")
    
    def _clean_gap_content(self, content: str) -> str:
        """Clean gap analysis content"""
        # Remove any non-CSV content and clean up
        lines = content.strip().split('\n')
        cleaned_lines = []
        
        for line in lines:
            if line.strip() and not line.startswith('```'):
                cleaned_lines.append(line)
        
        return '\n'.join(cleaned_lines) 