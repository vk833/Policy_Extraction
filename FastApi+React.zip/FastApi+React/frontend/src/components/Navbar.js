import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { FaHome, FaUpload, FaFolder, FaChartBar, FaFileAlt } from 'react-icons/fa';

const NavigationBar = () => {
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <Navbar bg="primary" variant="dark" expand="lg" className="mb-4">
      <Container>
        <Navbar.Brand as={Link} to="/">
          <FaFileAlt className="me-2" />
          Travel Policy Analysis
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/" className={isActive('/')}>
              <FaHome className="me-1" />
              Home
            </Nav.Link>
            <Nav.Link as={Link} to="/upload" className={isActive('/upload')}>
              <FaUpload className="me-1" />
              Upload
            </Nav.Link>
            <Nav.Link as={Link} to="/files" className={isActive('/files')}>
              <FaFolder className="me-1" />
              Files
            </Nav.Link>
            <Nav.Link as={Link} to="/analysis" className={isActive('/analysis')}>
              <FaChartBar className="me-1" />
              Analysis
            </Nav.Link>
            <Nav.Link as={Link} to="/summary" className={isActive('/summary')}>
              <FaFileAlt className="me-1" />
              Summary
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default NavigationBar; 