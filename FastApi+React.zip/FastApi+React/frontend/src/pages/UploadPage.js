import React, { useState, useCallback } from 'react';
import { Container, Row, Col, Card, Button, Alert, ProgressBar, Spinner } from 'react-bootstrap';
import { useDropzone } from 'react-dropzone';
import { toast } from 'react-toastify';
import { FaUpload, FaFilePdf, FaFileExcel } from 'react-icons/fa';
import axios from 'axios';

const UploadPage = () => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState([]);

  const onDrop = useCallback((acceptedFiles) => {
    acceptedFiles.forEach(file => {
      uploadFile(file);
    });
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls']
    },
    multiple: true
  });

  const uploadFile = async (file) => {
    setUploading(true);
    setUploadProgress(0);

    const formData = new FormData();
    formData.append('file', file);

    try {
      let endpoint = '';
      if (file.type === 'application/pdf') {
        endpoint = '/api/upload/pdf';
      } else if (file.type.includes('excel') || file.type.includes('spreadsheet')) {
        endpoint = '/api/upload/template';
      } else {
        toast.error('Unsupported file type');
        return;
      }

      const response = await axios.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(progress);
        },
      });

      if (response.data.status === 'processing') {
        toast.success(`${file.name} uploaded successfully! Processing in background...`);
        setUploadedFiles(prev => [...prev, { name: file.name, status: 'processing' }]);
        
        // Poll for status
        pollProcessingStatus(file.name);
      } else {
        toast.success(`${file.name} uploaded successfully!`);
        setUploadedFiles(prev => [...prev, { name: file.name, status: 'completed' }]);
      }

    } catch (error) {
      console.error('Upload error:', error);
      toast.error(`Error uploading ${file.name}: ${error.response?.data?.detail || error.message}`);
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const pollProcessingStatus = async (filename) => {
    const maxAttempts = 30; // 5 minutes with 10-second intervals
    let attempts = 0;

    const poll = async () => {
      try {
        const response = await axios.get(`/api/upload/status/${filename}`);
        
        if (response.data.status === 'completed') {
          toast.success(`${filename} processing completed!`);
          setUploadedFiles(prev => 
            prev.map(file => 
              file.name === filename ? { ...file, status: 'completed' } : file
            )
          );
          return;
        }
        
        attempts++;
        if (attempts < maxAttempts) {
          setTimeout(poll, 10000); // Poll every 10 seconds
        } else {
          toast.warning(`${filename} processing is taking longer than expected. Check the files page for updates.`);
          setUploadedFiles(prev => 
            prev.map(file => 
              file.name === filename ? { ...file, status: 'timeout' } : file
            )
          );
        }
      } catch (error) {
        console.error('Status check error:', error);
        attempts++;
        if (attempts < maxAttempts) {
          setTimeout(poll, 10000);
        }
      }
    };

    setTimeout(poll, 5000); // Start polling after 5 seconds
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'processing':
        return <Spinner animation="border" size="sm" className="text-warning" />;
      case 'completed':
        return <span className="text-success">✓</span>;
      case 'timeout':
        return <span className="text-warning">⏰</span>;
      default:
        return null;
    }
  };

  return (
    <Container className="py-4">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card>
            <Card.Header>
              <h3 className="mb-0">
                <FaUpload className="me-2" />
                Upload Travel Policy Documents
              </h3>
            </Card.Header>
            <Card.Body>
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded p-5 text-center ${
                  isDragActive ? 'border-primary bg-light' : 'border-secondary'
                }`}
                style={{ cursor: 'pointer' }}
              >
                <input {...getInputProps()} />
                <FaUpload className="display-4 text-muted mb-3" />
                {isDragActive ? (
                  <p className="lead">Drop the files here...</p>
                ) : (
                  <div>
                    <p className="lead">Drag & drop files here, or click to select files</p>
                    <p className="text-muted">
                      Supported formats: PDF (travel policy), Excel (template)
                    </p>
                    <div className="mt-3">
                      <FaFilePdf className="text-danger me-3" size={24} />
                      <FaFileExcel className="text-success" size={24} />
                    </div>
                  </div>
                )}
              </div>

              {uploading && (
                <div className="mt-4">
                  <ProgressBar 
                    now={uploadProgress} 
                    label={`${uploadProgress}%`}
                    variant="primary"
                  />
                  <p className="text-center mt-2">Uploading...</p>
                </div>
              )}

              {uploadedFiles.length > 0 && (
                <div className="mt-4">
                  <h5>Uploaded Files:</h5>
                  <div className="list-group">
                    {uploadedFiles.map((file, index) => (
                      <div key={index} className="list-group-item d-flex justify-content-between align-items-center">
                        <span>{file.name}</span>
                        <div className="d-flex align-items-center">
                          {getStatusIcon(file.status)}
                          <span className="ms-2">
                            {file.status === 'processing' && 'Processing...'}
                            {file.status === 'completed' && 'Completed'}
                            {file.status === 'timeout' && 'Timeout'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <Alert variant="info" className="mt-4">
                <h6>Upload Guidelines:</h6>
                <ul className="mb-0">
                  <li>Upload PDF travel policy documents for analysis</li>
                  <li>Upload Excel template files for structured processing</li>
                  <li>Files are processed asynchronously - you can continue using the app</li>
                  <li>Check the Files page to view processing results</li>
                </ul>
              </Alert>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default UploadPage; 