import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaUpload, FaChartBar, FaFileAlt, FaFolder } from 'react-icons/fa';

const HomePage = () => {
  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col md={10}>
          <div className="text-center mb-5">
            <h1 className="display-4 mb-3">AI Travel Policy Assistant</h1>
            <p className="lead">
              Upload your travel policy documents and get comprehensive analysis, gap assessment, and recommendations.
            </p>
          </div>

          <Row className="g-4">
            <Col md={6} lg={3}>
              <Card className="h-100 text-center">
                <Card.Body>
                  <FaUpload className="display-4 text-primary mb-3" />
                  <Card.Title>Upload Policy</Card.Title>
                  <Card.Text>
                    Upload your PDF travel policy documents and Excel templates for analysis.
                  </Card.Text>
                  <Button as={Link} to="/upload" variant="primary">
                    Start Upload
                  </Button>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={3}>
              <Card className="h-100 text-center">
                <Card.Body>
                  <FaFolder className="display-4 text-success mb-3" />
                  <Card.Title>View Files</Card.Title>
                  <Card.Text>
                    Browse and manage your uploaded files, processed results, and analysis reports.
                  </Card.Text>
                  <Button as={Link} to="/files" variant="success">
                    Browse Files
                  </Button>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={3}>
              <Card className="h-100 text-center">
                <Card.Body>
                  <FaChartBar className="display-4 text-warning mb-3" />
                  <Card.Title>Gap Analysis</Card.Title>
                  <Card.Text>
                    Run comprehensive gap analysis on your travel policy to identify areas for improvement.
                  </Card.Text>
                  <Button as={Link} to="/analysis" variant="warning">
                    Run Analysis
                  </Button>
                </Card.Body>
              </Card>
            </Col>

            <Col md={6} lg={3}>
              <Card className="h-100 text-center">
                <Card.Body>
                  <FaFileAlt className="display-4 text-info mb-3" />
                  <Card.Title>Summary Report</Card.Title>
                  <Card.Text>
                    Generate executive summary reports with recommendations and action items.
                  </Card.Text>
                  <Button as={Link} to="/summary" variant="info">
                    Generate Report
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          <Row className="mt-5">
            <Col md={12}>
              <Card>
                <Card.Header>
                  <h4>How It Works</h4>
                </Card.Header>
                <Card.Body>
                  <Row>
                    <Col md={3}>
                      <div className="text-center">
                        <div className="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center" style={{width: '60px', height: '60px'}}>
                          <strong>1</strong>
                        </div>
                        <h6 className="mt-2">Upload</h6>
                        <p className="small">Upload your travel policy PDF and template files</p>
                      </div>
                    </Col>
                    <Col md={3}>
                      <div className="text-center">
                        <div className="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center" style={{width: '60px', height: '60px'}}>
                          <strong>2</strong>
                        </div>
                        <h6 className="mt-2">Process</h6>
                        <p className="small">AI processes and extracts policy information</p>
                      </div>
                    </Col>
                    <Col md={3}>
                      <div className="text-center">
                        <div className="bg-warning text-white rounded-circle d-inline-flex align-items-center justify-content-center" style={{width: '60px', height: '60px'}}>
                          <strong>3</strong>
                        </div>
                        <h6 className="mt-2">Analyze</h6>
                        <p className="small">Run gap analysis to identify improvements</p>
                      </div>
                    </Col>
                    <Col md={3}>
                      <div className="text-center">
                        <div className="bg-info text-white rounded-circle d-inline-flex align-items-center justify-content-center" style={{width: '60px', height: '60px'}}>
                          <strong>4</strong>
                        </div>
                        <h6 className="mt-2">Report</h6>
                        <p className="small">Generate comprehensive summary reports</p>
                      </div>
                    </Col>
                  </Row>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </Container>
  );
};

export default HomePage; 