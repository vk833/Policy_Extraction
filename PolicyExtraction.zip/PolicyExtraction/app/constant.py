from enum import Enum

from fastapi import Path
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()
PROMPT_ID_DEV=os.getenv('PROMPT_ID_DEV')
CLIENT_ID_DEV=os.getenv('CLIENT_ID_DEV')
CLIENT_ID_SECRET=os.getenv('CLIENT_ID_SECRET')
print(PROMPT_ID_DEV,CLIENT_ID_DEV,CLIENT_ID_SECRET)
if not (PROMPT_ID_DEV and CLIENT_ID_DEV and CLIENT_ID_SECRET ):
    raise ValueError("environment variables are not set correctly.")

class Environment(Enum):
    DEV = 'dev'
    PROD = 'prod'

class PromptId(Enum):
    DEV = os.getenv('PROMPT_ID_DEV')

class ClientId(Enum):
    DEV = os.getenv('CLIENT_ID_DEV')
    
print(ClientId.DEV)  

class ClientSecret(Enum):
    DEV = os.getenv('CLIENT_ID_SECRET')
    

# class ProjectId(Enum):
#     DEV = os.getenv('PROJECT_ID_DEV')
#     PROD = os.getenv('PROJECT_ID_PROD')


# # Directory Configuration
# BASE_DIR = Path(__file__).resolve().parent
# UPLOAD_DIR = BASE_DIR / "uploads"
# INPUT_DIR=BASE_DIR / "input"
# OUTPUT_DIR=BASE_DIR / "Outputs"
