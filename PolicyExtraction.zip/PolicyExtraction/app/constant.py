from enum import Enum

class Environment(Enum):
    DEV = 'dev'
    PROD = 'prod'

class PromptId(Enum):
    DEV = '/'
    PROD = '/'

class ClientSecret(Enum):
    DEV = 'FncACEGB5wEEIVeb03pRFJmedkNB83ovqGehuTIPHaO4uMgjptDZrxjIj8wL-E7g'
    PROD = '/'

class ProjectId(Enum):
    DEV = '/'
    PROD = '/'

class Client(Enum):
    DEV = '0oa22vjw81t8kgb4x0h8'
    PROD = '/'





# from enum import Enum

# from fastapi import Path
# from dotenv import load_dotenv
# import os

# # Load environment variables from .env file
# load_dotenv()

# class Environment(Enum):
#     DEV = 'dev'
#     PROD = 'prod'

# class PromptId(Enum):
#     DEV = os.getenv('PROMPT_ID_DEV', '')
#     PROD = os.getenv('PROMPT_ID_PROD', '')

# class ClientId(Enum):
#     DEV = os.getenv('CLIENT_ID_DEV', '')
#     PROD = os.getenv('CLIENT_ID_PROD', '')

# class ClientSecret(Enum):
#     DEV = os.getenv('CLIENT_ID_SECRET', '')
#     PROD = os.getenv('CLIENT_ID_SECRET_PROD', '')

# class ProjectId(Enum):
#     DEV = os.getenv('PROJECT_ID_DEV', '')
#     PROD = os.getenv('PROJECT_ID_PROD', '')



# # Directory Configuration
# BASE_DIR = Path(__file__).resolve().parent
# UPLOAD_DIR = BASE_DIR / "uploads"
# INPUT_DIR=BASE_DIR / "input"
# OUTPUT_DIR=BASE_DIR / "Outputs"
