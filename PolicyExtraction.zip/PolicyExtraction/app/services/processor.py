import csv
from io import StringIO
import os, asyncio
import aiohttp
import pandas as pd
from pandas.errors import EmptyDataError
from fastapi import HTTPException
from app.utils.helper import convert_pdf_to_text1, wrap_in_quotes
from app.auth.token import generate_access_token
# from app.constant import expected_columns
from app.utils.helper import preprocess_csv_files_For_PolicyExtraction


token=generate_access_token('dev')

expected_columns = [
                "Client Content",
                "Rating",
                "Points",
                "Gap Analysis"
            ]
async def process_upload(pdf_file):
    input_dir = "input/"
    csv_file_path = os.path.join(input_dir, "Template.xlsx")
    upload_dir = "uploads/"
    outputs_dir = "Outputs/"

    os.makedirs(upload_dir, exist_ok=True)
    os.makedirs(outputs_dir, exist_ok=True)

    pdf_path = os.path.join(upload_dir, pdf_file.filename)
    with open(pdf_path, "wb") as f:
        f.write(await pdf_file.read())

    pdf_text = convert_pdf_to_text1(pdf_path)

    try:
        excel_data = pd.read_excel(csv_file_path, engine="openpyxl")
        print("Excel Data",excel_data)
        if "Category" not in excel_data.columns:
            raise HTTPException(status_code=400, detail="Excel must contain 'Category' column.")

        for col in excel_data.columns:
            if col != "Category":
                excel_data[col] = excel_data[col].map(wrap_in_quotes)

        category_counts = excel_data["Category"].value_counts().to_dict()
        unique_categories = list(category_counts.keys())
        excel_text = excel_data.to_json(index=False)

    except EmptyDataError:
        raise HTTPException(status_code=400, detail="Excel file is empty or invalid.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Excel processing error: {str(e)}")

    api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/ca99b671-639e-4612-8825-2b0b49cc958b/conversation"
    headers = {"Content-Type": "application/json", "X-Access-Token": token}

    results = await process_all_categories(
        unique_categories,
        category_counts,
        pdf_text,
        excel_text,
        api_url,
        headers,
        outputs_dir,
        expected_columns,
        excel_data,
    )

    errors = [r for r in results if r.startswith("Error")]
    if errors:
        return {"errors": errors}

    preprocess_csv_files_For_PolicyExtraction()
    return results

async def process_category(
    session,
    category,
    count,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns,
    excel_data,
    
):
    # print(count, " ", category)
    try:
        full_input = f"""
        This is a travel policy document (PDF1): {pdf_text}
        This is an Excel file (Excel1): {excel_text}

        Process the category '{category}'.
    Task :
    Must Do and Most MANDATORY INSTRUCTIONS FOR Rating, Do this for every row:
        Compare "Client Content" with "GBC BEST PRACTICE CONTENT" and assign a rating: 
        1.'Full', then fill "NO Gap" in the "Gap Analysis" column.
        2.'Null', then fill the reason and Gap Filled Content in the "Gap Analysis" column.
        3.'Partial', then fill the reason and Gap Filled Content in the "Gap Analysis" column.
        fill  in  Column which is the Last Column and put it in ("").
            "Format of Column use this format for every row:
                Rating is (Null/Partial)Because:(Give the Reason)
                Content:(Explanation)"
                -Write GapFilled Content is Paragraph and its not to long write in precise way
        MANDATORY INSTRUCTIONS:
        - Do NOT skip any rows of category:{category}, even if the count is {count} ,i want all {count} in single response even length is big.
        - Process ALL entries for this category. 
        - Output MUST be a valid CSV with the following columns in this exact order:
         "Client Content", "Rating", "Points", "Gap Analysis",
       

        
        
        - DO NOT allow any column displacement. Each value must stay in its correct column.
        - If any column contains commas, quotes, or line breaks, wrap the entire field in double quotes to preserve CSV structure.
        - Fix malformed rows caused by broken lines or misplaced commas.
        - DO NOT merge or duplicate columns.
        - DO NOT copy "GBC BEST PRACTICE CONTENT" into "Client Content".
        - "Client Content" must be detailed, accurate, and based on the policy document.
        - If "Type" is not blank, set "Maximum Score" to 0.
        - DO NOT include any explanation or text before or after the CSV.
        - Return ONLY the CSV content, clean and ready to be saved.
        
       
        ADDITIONAL INSTRUCTION FOR Data Integrity:
        -"Note: All input values are wrapped in double quotes. Do not displace or misaligned any column content."  
        - Ensure the category "{category}" is fully and accurately processed.       
        - Do NOT skip or omit any content from any column.
        - Each value from the input must be placed in its correct corresponding column in the output CSV.
        - Maintain the exact column structure and order as specified.
        - Do NOT merge, shift, or misplace any content across columns.
        - Pay special attention to preserving the integrity of each row’s data across all columns.       
        - Prevent column displacement due to commas, line breaks, or special characters in GBC BEST PRACTICE CONTENT .
        
    

        ADDITIONAL INSTRUCTION FOR "Client Content":
        - For each row, extract or paraphrase all relevant and specific content from the travel policy document (PDF1) that corresponds to the "Primary Content" and "Category", "Subcategory".
        - Include every applicable point from the policy. Do NOT summarize or merge multiple points into one—list them all clearly and completely.
        - Ensure "Client Content" is not generic. It must reflect the actual language, rules, or procedures stated in the policy.
        - If the policy contains multiple relevant clauses, include each one in full or paraphrased form, separated clearly (e.g., with bullet points or line breaks).
        - Prioritize accuracy and completeness. Do not leave "Client Content" blank unless the policy has absolutely no relevant information.
        - Do NOT copy or reference "GBC BEST PRACTICE CONTENT" in this column.
        - Strictly Follow = Wrap the entire "Client Content" field in double single quotes ("") to prevent column displacement due to commas, line breaks, or special characters.
        - Do NOT skip any rows of category:{category}, even if the count is {count} ,i want all {count} in single response even length is big.
        - Do not skip any row of {category} there are {count} number of cells i want all cells in output.
        - if the information is not present in Policy so do not make or put related information just put "Not available in policy document".
        - If specific information is not explicitly mentioned in the policy document, do not infer or include related details. Instead, clearly state: 'Not available in policy document'.
        important prompt
        - Output MUST be a valid CSV with the following columns in this exact order...
        - You MUST include the CSV header line exactly as specified, even if no data rows are present.

        
        
        """


        data = {
            "promptId": "58fc18e0-2ee3-46da-841e-2f494ffe2ce5",
            "messages": [],
            "input": {"input": full_input},
        }

        async with session.post(api_url, headers=headers, json=data, ssl=False) as resp:
            resp.raise_for_status()
            response_json = await resp.json()
            try:
                csv_string = response_json["data"]["messages"][0]["content"]
            except (KeyError, TypeError, IndexError) as e:
                raise ValueError(f"Failed to extract CSV content from response. Error: {e}\nRaw response: {response_json}")

           

            # Use regex to find the header line
            def find_csv_start(csv_string):
                for i, line in enumerate(csv_string.splitlines()):
                    cleaned_line = line.replace('\"', '').strip().lower()
                    if cleaned_line.startswith("client content,rating,points,gap analysis"):
                        return i
                return -1


            csv_lines = csv_string.splitlines()
            csv_start_index = find_csv_start(csv_string)

            if csv_start_index == -1:
                raise ValueError("CSV header not found in the response.")

            csv_data = '\n'.join(csv_lines[csv_start_index:])
            csv_data = (
                csv_data.replace('\\"', '"')
                        .replace("\\n", "\n")
                        .replace("_x000D_", "")
            )
            

            expected_fields = 4
            category  
            
            lines = csv_data.strip().split('\n')
            reader = csv.reader(lines)
            header = next(reader)
            # print("Headers:",header)
            cleaned_rows = [header]

            for row in reader:
                if len(row) == expected_fields:
                    cleaned_rows.append(row)
                elif len(row) == expected_fields - 1:
                    corrected_row = [category] + row
                    cleaned_rows.append(corrected_row)
                elif len(row) > expected_fields:
                    merged_last = ','.join(row[expected_fields - 1:])
                    trimmed_row = row[:expected_fields - 1] + [merged_last]
                    cleaned_rows.append(trimmed_row)
                    

            output = StringIO()
            writer = csv.writer(output)
            writer.writerows(cleaned_rows)
            # print("Cleaned Rows:",cleaned_rows)
            output.seek(0)

            df = pd.read_csv(output)


            df.columns = [col.strip() for col in df.columns]
            col_map = {col.lower(): col for col in df.columns}
            for expected in expected_columns:
                if expected not in df.columns:
                    match = col_map.get(expected.lower())
                    if match:
                        df.rename(columns={match: expected}, inplace=True)
                    else:
                        df[expected] = ""
            df = df[expected_columns]
            safe_filename = f"{category.replace(' ', '_')}.csv"
            df.to_csv(
                os.path.join(outputs_dir, safe_filename),
                index=False,
                encoding="utf-8",
                quoting=csv.QUOTE_ALL,
            )
            return f"Processed: {category}"

    except Exception as e:
        return f"Error processing category '{category}': {e}"



async def process_all_categories(
    categories,
    category_counts,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns,
    excel_data,
):
    excel_df = pd.read_json(StringIO(excel_text))

    async with aiohttp.ClientSession() as session:
        tasks = []

        for category in categories:
            count = category_counts[category]
            category_df = excel_df[excel_df["Category"] == category]
            chunk_text = category_df.to_json(index=False)

            tasks.append(
                process_category(
                    session,
                    category,
                    count,
                    pdf_text,
                    chunk_text,
                    api_url,
                    headers,
                    outputs_dir,
                    expected_columns,
                    excel_data,
                )
            )

        return await asyncio.gather(*tasks)

# number = 10


# async def process_all_categories(
#     categories,
#     category_counts,
#     pdf_text,
#     excel_text,
#     api_url,
#     headers,
#     outputs_dir,
#     expected_columns,
    
# ):
#     excel_df = pd.read_json(StringIO(excel_text))

#     async with aiohttp.ClientSession() as session:
#         tasks = []

#         for category in categories:
#             count = category_counts[category]
#             category_df = excel_df[excel_df["Category"] == category]

#             if count > number:
#                 chunks = [
#                     category_df.iloc[i : i + number] for i in range(0, count, number)
#                 ]
#                 for idx, chunk in enumerate(chunks, start=1):
#                     chunk_text = chunk.to_json(index=False)
#                     chunk_name = f"{category} - Part {idx}"
#                     tasks.append(
#                         process_category(
#                             session,
#                             chunk_name,
#                             len(chunk),
#                             pdf_text,
#                             chunk_text,
#                             api_url,
#                             headers,
#                             outputs_dir,
#                             expected_columns,
                            
#                         )
#                     )
#             else:
#                 chunk_text = category_df.to_json(index=False)
#                 tasks.append(
#                     process_category(
#                         session,
#                         category,
#                         count,
#                         pdf_text,
#                         chunk_text,
#                         api_url,
#                         headers,
#                         outputs_dir,
#                         expected_columns,
                        
#                     )
#                 )

#         return await asyncio.gather(*tasks)
