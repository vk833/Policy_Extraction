
from fastapi import APIRouter, UploadFile, File
from fastapi.responses import JSONResponse
from app.services.processor import process_upload

from fastapi import APIRouter
from app.auth.token import generate_access_token

router = APIRouter()

@router.get("/")
def read_root():
    return {"message": "Welcome to the Travel Policy API"}

# @router.get("/token")
# def get_token(env: str = "dev"):
#     token = generate_access_token(env)
#     if token:
#         return {"access_token": token}
#     return {"error": "Failed to generate access token"}




# @router.post("/upload/")
# async def upload_file(pdf_file: UploadFile = File(...)):
#     try:
#         result = await process_upload(pdf_file)
#         return JSONResponse(status_code=200, content=result)
#     except Exception as e:
#         return JSONResponse(status_code=500, content={"error": str(e)})
@router.post("/upload/")
async def upload_file(pdf_file: UploadFile = File(...)):
    try:
        result = await process_upload(pdf_file)
        return JSONResponse(status_code=200, content=result)
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})
