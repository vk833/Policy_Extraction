import requests

url = "http://127.0.0.1:8000/api/upload/"
file_path = r"C:\Users\vvarun8\Projects\PolicyExtraction\input\Gartner_Global Travel Policy final 62718.pdf"

with open(file_path, "rb") as f:
    files = {"pdf_file": f}
    response = requests.post(url, files=files)

print(response.status_code)
print(response.json())
