

from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()



from fastapi import FastAPI
from app.routers import router as api_router

from app.routers import router as upload_router



app = FastAPI(title="Travel Policy API", version="1.0")

app.include_router(api_router)


app.include_router(upload_router, prefix="/api")

