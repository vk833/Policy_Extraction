import os
import fitz
import re
import pandas as pd


def handle_uploaded_file(file, upload_dir):
    # Ensure only one file is in the upload directory
    for existing_file in os.listdir(upload_dir):
        file_path = os.path.join(upload_dir, existing_file)
        if os.path.isfile(file_path):
            os.remove(file_path)

    # Save the new file
    file_path = os.path.join(upload_dir, file.name)
    with open(file_path, "wb+") as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    return file_path


def convert_pdf_to_text1(pdf_path):
    text = ""
    with fitz.open(pdf_path) as doc:
        for page in doc:
            text += page.get_text()
    return text


def preprocess_csv_files_For_PolicyExtraction():
    output_dir = os.path.join("Outputs")
    input_dir = os.path.join("input")
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(input_dir, exist_ok=True)

    try:
        # Step 1: Combine files with similar base names (e.g., Part_1, Part_2)
        csv_files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
        file_groups = {}

        for file in csv_files:
            match = re.match(r"(.+?)_-_Part_\d+\.csv$", file)
            if match:
                base_name = match.group(1)
                file_groups.setdefault(base_name, []).append(file)

        for base, files in file_groups.items():
            dataframes = []
            for f in sorted(files):
                file_path = os.path.join(output_dir, f)
                try:
                    df = pd.read_csv(file_path)
                    if df.empty:
                        print(f" Skipped empty file: {f}")
                    else:
                        dataframes.append(df)
                except Exception as e:
                    print(f" Error reading file {f}: {e}")

            if dataframes:
                combined_df = pd.concat(dataframes, ignore_index=True)
                safe_base = re.sub(r'[\\/*?:"<>| ]+', "_", base).strip("_")
                combined_file_path = os.path.join(output_dir, f"{safe_base}.csv")
                combined_df.to_csv(combined_file_path, index=False)

                for f in files:
                    os.remove(os.path.join(output_dir, f))
            else:
                print(f" No valid data to combine for: {base}")

        # Step 2: Combine Sustainability and Wellbeing if both exist
        sustainability_file = os.path.join(output_dir, "Sustainability.csv")
        wellbeing_file = os.path.join(output_dir, "Wellbeing.csv")

        if os.path.exists(sustainability_file) and os.path.exists(wellbeing_file):
            df_sustainability = pd.read_csv(sustainability_file)
            df_wellbeing = pd.read_csv(wellbeing_file)

            combined_df = pd.concat([df_sustainability, df_wellbeing], ignore_index=True)
            combined_file_path = os.path.join(output_dir, "Sustainability_and_Wellbeing.csv")
            combined_df.to_csv(combined_file_path, index=False)

            os.remove(sustainability_file)
            os.remove(wellbeing_file)

        # Step 3: Clean "Client Content" column
        for filename in os.listdir(output_dir):
            if filename.endswith(".csv"):
                file_path = os.path.join(output_dir, filename)
                df = pd.read_csv(file_path)

                if "Client Content" in df.columns:
                    df["Client Content"] = (
                        df["Client Content"]
                        .astype(str)
                        .apply(lambda x: x[1:-1] if x.startswith('"') and x.endswith('"') else x)
                    )
                    df.to_csv(file_path, index=False)

        # Step 4: Combine all CSV files into one master file and save to Inputs
        all_csv_files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
        master_dataframes = []

        for file in all_csv_files:
            file_path = os.path.join(output_dir, file)
            try:
                df = pd.read_csv(file_path)
                if not df.empty:
                    master_dataframes.append(df)
            except Exception as e:
                print(f" Error reading file {file} for master merge: {e}")

        if master_dataframes:
            master_df = pd.concat(master_dataframes, ignore_index=True)
            master_file_path = os.path.join(input_dir, "All_Combined.xlsx")
            master_df.to_excel(master_file_path, index=False, engine='openpyxl')

    except Exception as e:
        print(f"Error during preprocessing: {e}")

def wrap_in_quotes(value):
    """Wrap the given value in double quotes."""
    return f'"{value}"'