import base64
import requests
import time
from app.constant import Client, ClientSecret  # Assuming these are Enums

last_token_gen_time = 0
access_token_cache = None

def generate_access_token(env):
    global last_token_gen_time, access_token_cache

    # Use Enum safely
    try:
        client_id = Client[env.upper()].value
        client_secret = ClientSecret[env.upper()].value
    except KeyError:
        raise ValueError(f"Invalid environment: {env}. Use 'DEV' or 'PROD'.")

    # Check cache validity (3300 seconds = 55 minutes)
    if access_token_cache and (time.time() - last_token_gen_time < 3300):
        return access_token_cache

    token_url = 'https://amexgbt.okta.com/oauth2/default/v1/token'
    credentials = f"{client_id}:{client_secret}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()

    headers = {
        'Authorization': f'Basic {encoded_credentials}',
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    data = {
        'grant_type': 'client_credentials'
    }

    response = requests.post(token_url, headers=headers, data=data)

    if response.status_code == 200:
        access_token = response.json().get('access_token')
        last_token_gen_time = time.time()
        access_token_cache = access_token
        return access_token
    else:
        print(f"Error: {response.status_code} - {response.text}")
        return None
# import base64
# import requests
# import time
# from app.constant import ClientId, ClientSecret

# last_token_gen_time = 0
# access_token_cache = None

# def generate_access_token(env: str):
#     global last_token_gen_time, access_token_cache

#     try:
#         client_id = ClientId[env.upper()].value
#         client_secret = ClientSecret[env.upper()].value
#     except KeyError:
#         raise ValueError(f"Invalid environment: {env}. Use 'DEV' or 'PROD'.")

#     if not client_id or not client_secret:
#         raise ValueError("Client ID or Secret is missing in environment variables.")

#     # Check cache validity (3300 seconds = 55 minutes)
#     if access_token_cache and (time.time() - last_token_gen_time < 3300):
#         return access_token_cache

#     token_url = 'https://amexgbt.okta.com/oauth2/default/v1/token'
#     credentials = f"{client_id}:{client_secret}"
#     encoded_credentials = base64.b64encode(credentials.encode()).decode()

#     headers = {
#         'Authorization': f'Basic {encoded_credentials}',
#         'Content-Type': 'application/x-www-form-urlencoded'
#     }

#     data = {
#         'grant_type': 'client_credentials'
#     }

#     response = requests.post(token_url, headers=headers, data=data)

#     if response.status_code == 200:
#         access_token = response.json().get('access_token')
#         last_token_gen_time = time.time()
#         access_token_cache = access_token
#         return access_token
#     else:
#         raise Exception(f"Token generation failed: {response.status_code} - {response.text}")
