import subprocess
import time
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class ReloadHandler(FileSystemEventHandler):
    def __init__(self):
        self.process = None
        self.start_server()

    def start_server(self):
        print("Starting Django server...")
        self.process = subprocess.Popen(["python", "manage.py", "runserver"])

    def stop_server(self):
        if self.process:
            print("Stopping Django server...")
            self.process.terminate()
            self.process.wait()

    def on_modified(self, event):
        if event.src_path.endswith(".py"):
            print(f"Detected change in {event.src_path}. Restarting server...")
            self.stop_server()
            self.start_server()

if __name__ == "__main__":
    path = "."  # Watch the current directory
    event_handler = ReloadHandler()
    observer = Observer()
    observer.schedule(event_handler, path=path, recursive=True)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        event_handler.stop_server()
    observer.join()
