import json
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
import re

from django.conf import settings
from .forms import UploadFileForm
import os
import html
import asyncio
import aiohttp
import pandas as pd
from io import StringIO
from pdfminer.high_level import extract_text
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import UploadFileForm
from pandas.errors import EmptyDataError
import requests
import warnings
from .Policy_Extraction_views import token

warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")



count = ""

import glob
def handle_uploaded_file(f, upload_dir):
    # Delete all PDF files in the upload directory
    pdf_files = glob.glob(os.path.join(upload_dir, "*.pdf"))
    for pdf in pdf_files:
        os.remove(pdf)

    # Save the new uploaded file
    file_path = os.path.join(upload_dir, f.name)
    with open(file_path, "wb+") as destination:
        for chunk in f.chunks():
            destination.write(chunk)
    return file_path


def is_two_column_band(chars, mid_x, threshold=0.2):
    if not chars:
        return False
    left_count = sum(1 for c in chars if c["x0"] < mid_x)
    right_count = sum(1 for c in chars if c["x0"] >= mid_x)
    if max(left_count, right_count) == 0:
        return False
    return min(left_count, right_count) / max(left_count, right_count) > threshold
import pdfplumber
def convert_pdf_to_text1(pdf_path, band_height=100, overlap=30):
    extracted_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            extracted_text += f"\n--- Page {page_num} ---\n"
            page_width = page.width
            page_height = page.height
            mid_x = page_width / 2

            y_top = 0
            while y_top < page_height:
                y_bottom = min(y_top + band_height, page_height)
                band = page.within_bbox((0, y_top, page_width, y_bottom))
                chars = band.chars

                if is_two_column_band(chars, mid_x):
                    left_text = page.within_bbox((0, y_top, mid_x, y_bottom)).extract_text() or ""
                    right_text = page.within_bbox((mid_x, y_top, page_width, y_bottom)).extract_text() or ""
                    extracted_text += left_text + "\n" + right_text + "\n"
                else:
                    full_text = band.extract_text() or ""
                    extracted_text += full_text + "\n"

                y_top += band_height - overlap

    return extracted_text
def wrap_in_quotes(value):
    """Wrap the given value in double quotes."""
    return f'"{value}"'


async def process_category(
    session,
    category,
    count,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns,
    
):
    # print(count, " ", category)
    try:
        full_input = f"""
        My PdfText is={pdf_text}
You are an expert policy editor at AmexGBT. Your task is to perform a comprehensive gap analysis and rewrite the client's travel policy using AmexGBT best practices.

Compare the content of the uploaded PDF file with the Excel file for category: {category}.

Use the following Excel data:
{excel_text}

Instructions:
1. For each row in the Excel sheet where the "Rating" column is marked as "Partial" or "Null":
   - Generate a complete and appropriate policy statement using the "GBC BEST PRACTICE CONTENT", "Category", "SubCategory", and "Primary Content".
   - Add that statement to the "Gap Analysis" column only.
   - Label inserted content as “Gap Filled Content”.
   - Provide a reason for the rating:
     Format: Rating is (Partial/Null) because: [Reason]

2. For rows marked "Partial":
   - Identify missing elements in the "Client Content".
   - Supplement them using the "GBC BEST PRACTICE CONTENT", "Category", "SubCategory", and "Primary Content" to make the policy complete and aligned with best practices.

3. Maintain the original structure, tone, and formatting of the PDF:
   - This PDF is formatted in two columns. Extract the text by reading the left column top to bottom first, then the right column.
   - Maintain the original section headers and logical flow.
   - Do not merge text from both columns horizontally.

4. Insert missing best practices into the "Gap Analysis" column only.
   - Label inserted content as “Gap Filled Content”.
   - Maintain structure, formatting, and tone.
5. If Rating is 'Full' so fill "No Gap" in Gap analysis column.
6. write whole content of ("Category", "Subcategory", "Primary Content", "Type", "Client Content", "Rating", "Points", "Maximum Score", "GBC BEST PRACTICE CONTENT") these column as it is write every line or word do not skip.
 Important: Return only the final result in **valid CSV format** with the following columns:
"Category", "Subcategory", "Primary Content", "Type", "Client Content", "Rating", "Points", "Maximum Score", "GBC BEST PRACTICE CONTENT", "Gap Analysis"
write other Column Content as it is generate Gap analysis column  
Do not modify any column except "Gap Analysis". Do not include any introductory text or explanation. Only return the CSV content.
Do it in single response
if the {category} has {count} cell so do not skip any cell and do not skip any column content.
if there is a "," in between the column content so do not split it based on ","
-"Note: All input values are wrapped in double quotes. Do not displace or misaligned any column content."  

"Format of Gap analysis Column:
Rating is (Null/Partial)Because:(Give the Reason)
Content:(Explanation)"
-Write GapFilled Content is Paragraph and its not to long write in precise way
-do not give me other csv file like'[Continued_in_next_part_due_to_length_limit...].csv'give me the response in single api call

       
        """


        data = {
            "promptId": "2eef24fc-8a24-4aa3-a24f-61d32d23352a",
            "messages": [],
            "input": {"input": full_input},
        }

        async with session.post(api_url, headers=headers, json=data, ssl=False) as resp:
            resp.raise_for_status()
            response_json = await resp.json()
            try:
                csv_string = response_json["data"]["messages"][0]["content"]
            except (KeyError, TypeError, IndexError) as e:
                raise ValueError(f"Failed to extract CSV content from response. Error: {e}\nRaw response: {response_json}")


            
            # match = re.search(
            #     r"(?i)^category\s*,\s*subcategory.*$", csv_string, re.MULTILINE
            # )
            # if not match:
            #     raise ValueError("CSV header not found in the response.")

            # # csv_start = match.start()
            # def find_csv_start(csv_string):
            #     for i, line in enumerate(csv_string.splitlines()):
            #         normalized = ','.join(part.strip().lower() for part in line.split(','))
            #         if normalized.startswith("category,subcategory"):
            #             return i
            #     return -1
            def find_csv_start(csv_string):
                for i, line in enumerate(csv_string.splitlines()):
                    # Remove quotes and normalize
                    cleaned_line = line.replace('"', '').strip().lower()
                    if cleaned_line.startswith("category,subcategory"):
                        return i
                return -1

            csv_lines = csv_string.splitlines()
            csv_start_index = find_csv_start(csv_string)

            if csv_start_index == -1:
                raise ValueError("CSV header not found in the response.")

            csv_data = '\n'.join(csv_lines[csv_start_index:])
            csv_data = (
                csv_data.replace('\\"', '"')
                        .replace("\\n", "\n")
                        .replace("_x000D_", "")
            )

            # csv_data = (
            #     csv_string[csv_start:]
            #     .replace('\\"', '"')
            #     .replace("\\n", "\n")
            #     .replace("_x000D_", "")
            # )

            df = pd.read_csv(StringIO(csv_data), on_bad_lines="skip")
            df.columns = [col.strip() for col in df.columns]
            col_map = {col.lower(): col for col in df.columns}
            for expected in expected_columns:
                if expected not in df.columns:
                    match = col_map.get(expected.lower())
                    if match:
                        df.rename(columns={match: expected}, inplace=True)
                    else:
                        df[expected] = ""
            df = df[expected_columns]
            safe_filename = f"{category.replace(' ', '_')}.csv"
            df.to_csv(
                os.path.join(outputs_dir, safe_filename),
                index=False,
                encoding="utf-8",
                quoting=csv.QUOTE_ALL,
            )
            return f"Processed: {category}"

    except Exception as e:
        return f"Error processing category '{category}': {e}"


from io import StringIO
import pandas as pd
import aiohttp
import asyncio

number = 9


async def process_all_categories(
    categories,
    category_counts,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns,
    
):
    
    excel_df = pd.read_json(StringIO(excel_text))



    async with aiohttp.ClientSession() as session:
        tasks = []

        for category in categories:
            count = category_counts[category]
            category_df = excel_df[excel_df["Category"] == category]

            if count > number:
                chunks = [
                    category_df.iloc[i : i + number] for i in range(0, count, number)
                ]
                for idx, chunk in enumerate(chunks, start=1):
                    chunk_text = chunk.to_json(index=False)
                    chunk_name = f"{category} - Part {idx}"
                    tasks.append(
                        process_category(
                            session,
                            chunk_name,
                            len(chunk),
                            pdf_text,
                            chunk_text,
                            api_url,
                            headers,
                            outputs_dir,
                            expected_columns,
                            
                        )
                    )
            else:
                chunk_text = category_df.to_json(index=False)
                tasks.append(
                    process_category(
                        session,
                        category,
                        count,
                        pdf_text,
                        chunk_text,
                        api_url,
                        headers,
                        outputs_dir,
                        expected_columns,
                        
                    )
                )

        return await asyncio.gather(*tasks)


from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
import os
import glob
import pandas as pd
import asyncio
import html
from pandas.errors import EmptyDataError


def Gap_Analysis(request):
    if request.method != "POST":
        return JsonResponse({
            "success": False,
            "message": "Only POST requests are allowed."
        }, status=405)

    print("Received POST request for Gap Analysis.")

    upload_folder = "uploads/"
    input_dir = "input/"
    outputs_dir = "GapFilled/"
    excel_path = os.path.join(input_dir, "All_Combined.xlsx")

    os.makedirs(upload_folder, exist_ok=True)
    os.makedirs(outputs_dir, exist_ok=True)

    # Check for exactly one PDF
    pdf_files = glob.glob(os.path.join(upload_folder, "*.pdf"))
    if len(pdf_files) != 1:
        return JsonResponse({
            "success": False,
            "error": f"Expected exactly one PDF file in upload folder, found {len(pdf_files)}"
        })

    pdf_path = pdf_files[0]
    print(f"Processing file: {os.path.basename(pdf_path)}")

    try:
        print("Converting PDF to text...")
        pdf_text = convert_pdf_to_text1(pdf_path)

        print("Reading Excel file...")
        all_sheets = pd.read_excel(excel_path, sheet_name=None, engine="openpyxl")
        excel_data = pd.concat(all_sheets.values(), ignore_index=True)

        if "Category" not in excel_data.columns:
            return HttpResponse("The Excel file must contain a 'Category' column.", status=400)

        for col in excel_data.columns:
            if col != "Category":
                excel_data[col] = excel_data[col].map(wrap_in_quotes)

        category_counts = excel_data["Category"].value_counts().to_dict()
        unique_categories = list(category_counts.keys())
        excel_text = excel_data.to_json(index=False)

    except EmptyDataError:
        return HttpResponse("The uploaded Excel file is empty or invalid.", status=400)
    except Exception as e:
        print("Error while processing Excel:", e)
        return HttpResponse(f"An error occurred while processing the Excel file: {e}", status=500)


    api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/ca99b671-639e-4612-8825-2b0b49cc958b/conversation"
    headers = {"Content-Type": "application/json", "X-Access-Token": token}

    expected_columns = [
        "Category", "Subcategory", "Primary Content", "Type", "Client Content",
        "Rating", "Points", "Maximum Score", "GBC BEST PRACTICE CONTENT", "Gap analysis"
    ]

    try:
        print("Starting async processing of categories...")
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        results = loop.run_until_complete(
            process_all_categories(
                unique_categories,
                category_counts,
                pdf_text,
                excel_text,
                api_url,
                headers,
                outputs_dir,
                expected_columns,
                
            )
        )

        print("Processing results:", results)
        preprocess_csv_files()
        errors = [r for r in results if r.startswith("Error")]
        if errors:
            return HttpResponse(
                f"""
                <script>
                alert("{html.escape(str(errors))}");
                window.history.back();
                </script>
                """
            )
        
        
        print("Gap analysis completed successfully.")
        
        from django.shortcuts import redirect

        from django.urls import reverse

        from django.http import JsonResponse
        from django.urls import reverse

        # After successful processing
        redirect_url = reverse('views2_list_csv_files1')
        return JsonResponse({
            "success": True,
            "redirect_url": redirect_url
        })


        
    except Exception as e:
        print("Exception during async processing:", e)
        return HttpResponse(
            f"""
            <script>
            alert("{html.escape(str(e))}");
            window.history.back();
            </script>
            """
        )


def preprocess_csv_files():
    output_dir = os.path.join(settings.BASE_DIR, "GapFilled")
    #os.makedirs(output_dir, exist_ok=True)

    try:
        # Step 1: Combine files with similar base names (e.g., Part_1, Part_2)
        csv_files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
        file_groups = {}

        for file in csv_files:
            match = re.match(r"(.+?)_-_Part_\d+\.csv$", file)
            if match:
                base_name = match.group(1)
                file_groups.setdefault(base_name, []).append(file)

        for base, files in file_groups.items():
            dataframes = []
            for f in sorted(files):
                file_path = os.path.join(output_dir, f)
                try:
                    df = pd.read_csv(file_path)
                    if df.empty:
                        print(f"⚠️ Skipped empty file: {f}")
                    else:
                        dataframes.append(df)
                except Exception as e:
                    print(f"❌ Error reading file {f}: {e}")

            if dataframes:
                combined_df = pd.concat(dataframes, ignore_index=True)
                safe_base = re.sub(r'[\\/*?:"<>| ]+', "_", base).strip("_")
                combined_file_path = os.path.join(output_dir, f"{safe_base}.csv")
                combined_df.to_csv(combined_file_path, index=False)

                for f in files:
                    os.remove(os.path.join(output_dir, f))
            else:
                print(f"⚠️ No valid data to combine for: {base}")

        # Step 2: Combine Sustainability and Wellbeing if both exist
        sustainability_file = os.path.join(output_dir, "Sustainability.csv")
        wellbeing_file = os.path.join(output_dir, "Wellbeing.csv")

        if os.path.exists(sustainability_file) and os.path.exists(wellbeing_file):
            df_sustainability = pd.read_csv(sustainability_file)
            df_wellbeing = pd.read_csv(wellbeing_file)

            combined_df = pd.concat([df_sustainability, df_wellbeing], ignore_index=True)
            combined_file_path = os.path.join(output_dir, "Sustainability&Wellbeing.csv")
            combined_df.to_csv(combined_file_path, index=False)

            os.remove(sustainability_file)
            os.remove(wellbeing_file)

        # Step 3: Clean "Client Content" column
        for filename in os.listdir(output_dir):
            if filename.endswith(".csv"):
                file_path = os.path.join(output_dir, filename)
                df = pd.read_csv(file_path)

                if "Client Content" in df.columns:
                    df["Client Content"] = (
                        df["Client Content"]
                        .astype(str)
                        .apply(lambda x: x[1:-1] if x.startswith('"') and x.endswith('"') else x)
                    )
                    df.to_csv(file_path, index=False)
        

    except Exception as e:
        print(f"❌ Error during preprocessing: {e}")




outputs_dir="GapFilled"


def view_csv_file(request, filename):
    file_path = os.path.join(outputs_dir, filename)
    csv_data = []

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                csv_data.append(row)
    except FileNotFoundError:
        return HttpResponse(f"The file {filename} was not found.", status=404)

    return render(
        request, "views2_csv.html", {"csv_data": csv_data, "filename": filename}
    )



from django.shortcuts import render
import os

from django.shortcuts import render
import os

def views2_list_csv_files1(request):
    print("function started")
    gap_filled_dir = "GapFilled/"
    try:
        files = os.listdir(gap_filled_dir)
        csv_files = [f for f in files if f.endswith(".csv")]
    except Exception as e:
        csv_files = []
        print("Error reading GapFilled directory:", e)

    return render(request, "list_gapfilled_files1.html", {"csv_files": csv_files})


def download_csv(request):
    filename = request.GET.get("filename")
    if not filename:
        return HttpResponse("Filename not specified.", status=400)

    file_path = os.path.join("GapFilled", filename)

    try:
        with open(file_path, "rb") as f:
            response = HttpResponse(f.read(), content_type="text/csv")
            response["Content-Disposition"] = f"attachment; filename={filename}"
            return response
    except FileNotFoundError:
        return HttpResponse(f"The file {filename} was not found.", status=404)


import zipfile
from io import BytesIO


def download_all_csvs(request):
    directory = "GapFilled"
    zip_buffer = BytesIO()

    with zipfile.ZipFile(zip_buffer, "w") as zip_file:
        for filename in os.listdir(directory):
            if filename.endswith(".csv"):
                file_path = os.path.join(directory, filename)
                zip_file.write(file_path, arcname=filename)

    zip_buffer.seek(0)
    response = HttpResponse(zip_buffer, content_type="application/zip")
    response["Content-Disposition"] = "attachment; filename=all_csv_files.zip"
    return response


import os
from django.http import JsonResponse


def check_csv(request):
    output_dir = "GapFilled"
    has_csv = any(fname.endswith(".csv") for fname in os.listdir(output_dir))
    return JsonResponse({"has_csv": has_csv})


import os
import pandas as pd
from django.http import HttpResponse, FileResponse
from django.shortcuts import render


def combine_csvs_view(request):
    outputs_folder = "GapFilled"
    output_file = "combined_sheets.xlsx"

    # List all CSV files in the Outputs folder
    csv_files = [f for f in os.listdir(outputs_folder) if f.endswith(".csv")]

    # Combine CSVs into Excel
    with pd.ExcelWriter(output_file, engine="xlsxwriter") as writer:
        for file in csv_files:
            file_path = os.path.join(outputs_folder, file)
            df = pd.read_csv(file_path)
            sheet_name = os.path.splitext(file)[0]
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    return FileResponse(
        open(output_file, "rb"), as_attachment=True, filename=output_file
    )
