

# views.import os
import asyncio
import aiohttp
from django.shortcuts import redirect, render
import pandas as pd
from io import StringIO
from docx import Document
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import glob
import requests
import pdfplumber
import urllib3
import requests
import pandas as pd
import pdfplumber
import asyncio
import aiohttp
from docx import Document
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .Policy_Extraction_views import token
import os
# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Constants
input_dir = "input/"
excel_path = os.path.join(input_dir, "All_Combined.xlsx")
output_dir = "output"
output_path = os.path.join(output_dir, "combined_policy_document.docx")

def is_two_column_page(chars, mid_x, threshold=0.3):
    if not chars:
        return False
    left_count = sum(1 for c in chars if c["x0"] < mid_x)
    right_count = sum(1 for c in chars if c["x0"] >= mid_x)
    if max(left_count, right_count) == 0:
        return False
    return min(left_count, right_count) / max(left_count, right_count) > threshold

def convert_pdf_to_text(pdf_path, band_height=100, overlap=30):
    extracted_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            page_width = page.width
            page_height = page.height
            mid_x = page_width / 2

            page_chars = page.chars
            two_column = is_two_column_page(page_chars, mid_x)

            y_top = 0
            while y_top < page_height:
                y_bottom = min(y_top + band_height, page_height)
                band = page.within_bbox((0, y_top, page_width, y_bottom))

                if two_column:
                    left_text = page.within_bbox((0, y_top, mid_x, y_bottom)).extract_text() or ""
                    right_text = page.within_bbox((mid_x, y_top, page_width, y_bottom)).extract_text() or ""
                    extracted_text += left_text + "\n" + right_text + "\n"
                else:
                    full_text = band.extract_text() or ""
                    extracted_text += full_text + "\n"

                y_top += band_height - overlap

    return extracted_text

def read_excel_as_json(excel_path):
    df = pd.read_excel(excel_path, engine="openpyxl")
    for col in df.columns:
        if col != "Category":
            df[col] = df[col].map(lambda val: f'"{val}"' if pd.notnull(val) else "")
    return df.to_json(orient="records")
import os
import pandas as pd
from io import StringIO
from docx import Document
import aiohttp
import asyncio

async def process_categories_and_generate_summary(
    categories,
    category_counts,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns
):
    try:
        excel_df = pd.read_json(StringIO(excel_text))

        if expected_columns:
            missing_columns = [col for col in expected_columns if col not in excel_df.columns]
            if missing_columns:
                raise ValueError(f"Missing expected columns in Excel data: {missing_columns}")

        combined_document = Document()

        async with aiohttp.ClientSession() as session:
            tasks = []

            for category in categories:
                category_df = excel_df[excel_df["Category"] == category]
                chunk_text = category_df.to_json(index=False)
                full_input = f""" f"This is Policy Document Text :{pdf_text}"
                                f"This is Excel Text:{excel_text}"
                                f"Compare the content of the uploaded PDF file with the Excel file for category: {category}.\n"
                                "Generate the Summary only in 4 to 5 lines.\n"
                                "Write Category name in response only once\n"
                                "Format:\n"
                                f"Summary For Category:{category}\n"
                                "Write precise Summary on Gap Analysis\n"
                                """
                conversation_data= {
                    "promptId": "db13a44a-16ea-4c43-ba67-6658c5567c02",
                    "messages": [],
                    "input": {"input": full_input},
                }

                
                tasks.append(
                    session.post(api_url, headers=headers, json=conversation_data, ssl=False)
                )

            responses = await asyncio.gather(*tasks)

            for category, response in zip(categories, responses):
                if response.status == 200:
                    try:
                        data = await response.json()
                        messages = data.get("data", {}).get("messages", [])
                        summary = messages[-1].get("content", "") if messages else f"No summary for category {category}"
                    except Exception as e:
                        summary = f"Error parsing response for category {category}: {e}"
                else:
                    error_text = await response.text()
                    summary = f"Error: No response for category {category}. Status: {response.status}. Details: {error_text}"

                combined_document.add_heading(f"{category}", level=1)
                combined_document.add_paragraph(summary)

        os.makedirs(outputs_dir, exist_ok=True)
        output_path = os.path.join(outputs_dir, "Gap_Summary.docx")
        combined_document.save(output_path)
        print(f"Summary document saved at: {output_path}")

    except Exception as e:
        print(f"An error occurred: {e}")



@csrf_exempt
def generate_summary(request):
    if request.method == "POST":
        upload_folder = "uploads/"
        pdf_files = glob.glob(os.path.join(upload_folder, "*.pdf"))

        if len(pdf_files) != 1:
            return JsonResponse({
                "success": False,
                "error": f"Expected exactly one PDF file in upload folder, found {len(pdf_files)}"
            })

        pdf_path = pdf_files[0]
        print(f"Processing file: {os.path.basename(pdf_path)}")

        try:
            pdf_text = convert_pdf_to_text(pdf_path)
            excel_text = read_excel_as_json(excel_path)

            excel_df = pd.read_json(StringIO(excel_text))
            categories = excel_df["Category"].unique().tolist()
            category_counts = excel_df["Category"].value_counts().to_dict()

            api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/ca99b671-639e-4612-8825-2b0b49cc958b/conversation"
            headers = {
                "Content-Type": "application/json",
                "X-Access-Token": token,
            }

            asyncio.run(process_categories_and_generate_summary(
                categories,
                category_counts,
                pdf_text,
                excel_text,
                api_url,
                headers,
                output_dir,
                expected_columns=None
            ))

            return redirect("show_pdf")

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)})

    return JsonResponse({"success": False, "error": "Only POST method is allowed"})

import os
from django.http import FileResponse, Http404
from django.conf import settings
from docx2pdf import convert
import tempfile

def successful_view(request):
    
    return render(request, "successful.html")

def show_pdf(request):
    try:
        # Define paths
        docx_path = os.path.join(
            settings.BASE_DIR, "output", "Gap_Summary.docx"
        )
        temp_dir = tempfile.mkdtemp()
        pdf_path = os.path.join(temp_dir, "document.pdf")

        # Convert DOCX to PDF
        convert(docx_path, pdf_path)

        # Serve the PDF
        return FileResponse(open(pdf_path, "rb"), content_type="application/pdf")

    except Exception as e:
        raise Http404(f"Error generating PDF: {e}")