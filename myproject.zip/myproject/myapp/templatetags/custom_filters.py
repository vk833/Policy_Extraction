from django import template

register = template.Library()

@register.filter
def clean_filename(value):
    """Remove .csv and replace underscores with spaces."""
    return value.replace('.csv', '').replace('_', ' ')
