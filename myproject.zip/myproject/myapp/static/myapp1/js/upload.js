
// function showFileName() {
//     const input = document.getElementById('pdf_file');
//     const fileNameDisplay = document.getElementById('file-name');
//     fileNameDisplay.textContent = input.files.length > 0 ? input.files[0].name : 'No file chosen';
// }

function showLoadingMessage() {
    document.getElementById('overlay').style.display = 'flex';
    return true; // Let the form submit normally
}


function showFileName() {
    const input = document.getElementById('pdf_file');
    const labelText = document.getElementById('file-label-text');
    if (input.files.length > 0) {
        const fileName = input.files[0].name;
        labelText.textContent = fileName;
        labelText.title = fileName;
    } else {
        labelText.textContent = 'Choose PDF';
        labelText.title = '';
    }
}


function checkForCSV() {
    fetch('/check_csv/')
        .then(response => response.json())
        .then(data => {
            if (data.has_csv) {
                window.location.href = '/successful/';
            } else {
                window.alert('Output is empty. Execute it first.');
            }
        })
        .catch(error => {
            console.error('Error checking CSV files:', error);
            window.alert('An error occurred while checking for CSV files.');
        });
}

// ✅ Combine input and submit
function prepareAndSubmitForm() {
    const userInput = document.getElementById('additional_input').value.trim();
    const combinedField = document.getElementById('combined_input');

    combinedField.value = userInput;
    console.log("Combined Input:", combinedField.value);

    document.getElementById('overlay').style.display = 'flex';
    return true; // Allow form to submit
}
