// Optional: Add a confirmation before downloading all files
document.querySelector('.download-all form')?.addEventListener('submit', function(e) {
    if (!confirm('Are you sure you want to download all CSV files as a ZIP?')) {
        e.preventDefault();
    }
});