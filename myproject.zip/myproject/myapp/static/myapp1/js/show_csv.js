document.querySelectorAll('.csv-link').forEach(link => {
    link.addEventListener('click', function(event) {
        const filename = this.getAttribute('data-filename');
        console.log('Opening file:', filename);
        this.style.color = '#28a745'; // temporary color change
        setTimeout(() => {
            this.style.color = ''; // revert after short delay
        }, 300);
    });
});