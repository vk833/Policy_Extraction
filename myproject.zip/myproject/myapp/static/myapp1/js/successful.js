window.addEventListener('load', function () {
    const popup = document.getElementById('popup-message');
    popup.style.display = 'block';
});

