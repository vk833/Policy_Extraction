# from django.urls import path
# from . import views

# urlpatterns = [
#     path('', views.upload_files, name='upload_files'),
#     path('show_csv/', views.show_response_csv, name='show_response_csv'),
#     #path('download_csv/', views.download_csv, name='download_csv'),
#     path('view_csv/<str:filename>/', views.view_csv_file, name='view_csv_file'),
    
#     path('list-files/', views.list_csv_files, name='list_csv_files'),
#     path('download-csv/', views.download_csv, name='download_csv'),
#     path('download-all-csvs/', views.download_all_csvs, name='download_all_csvs'),
#     path('successful/', views.successful_view, name='successful'),
    

#     path('check_csv/', views.check_csv, name='check_csv'),





# ]
from django.urls import path

from . import Gap_Analysis_views
from . import Policy_Extraction_views
from . import Gap_Summary_views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', Policy_Extraction_views.upload_files, name='upload_files'),
    
    # path('run-gap-prompt/', views.run_gap_prompt_view, name='run_gap_prompt'),


    
    path('list-files/', Policy_Extraction_views.list_csv_files_combined, name='list_csv_files'),
    path('combine-list-csv/', Policy_Extraction_views.combine_and_list_csv_files, name='combine_list_csv'),
    # CSV file actions
    path('download-csv/', Policy_Extraction_views.download_csv, name='download_csv'),
    path('download-all-csvs/', Policy_Extraction_views.download_all_csvs, name='download_all_csvs'),
    path('view_csv/<str:filename>/', Policy_Extraction_views.view_csv_file, name='view_csv_file'),
    # Other views
    path('successful/', Policy_Extraction_views.successful_view, name='successful'),
    path('check_csv/', Policy_Extraction_views.check_csv, name='check_csv'), 
    path('combine-csvs/', Policy_Extraction_views.combine_csvs_view, name='combine_csvs'),
    
    ################################################views2.py
    path('Gap-Analysis', Gap_Analysis_views.Gap_Analysis, name='Gap_Analysis'),
    path('list-gapfilled-files1/', Gap_Analysis_views.views2_list_csv_files1, name='views2_list_csv_files1'),
    path('views2-check_csv/', Gap_Analysis_views.check_csv, name='Views2_check_csv'),
    path('views2-view_csv/<str:filename>/', Gap_Analysis_views.view_csv_file, name='views2_csv_file'),
    path('views2-combine-csvs/', Gap_Analysis_views.combine_csvs_view, name='views2_combine_csvs'),
    path('views2-download-csv/', Gap_Analysis_views.download_csv, name='views2_download_csv'),
    path('views2-download-all-csvs/', Gap_Analysis_views.download_all_csvs, name='views2_download_all_csvs'),
    
    
    
    ################################################views3.py
    path('generate-summary', Gap_Summary_views.generate_summary, name='generate_summary'),
    path('show-pdf/', Gap_Summary_views.show_pdf, name='show_pdf'),
    path('successful/', Gap_Summary_views.successful_view, name='views3_successful'),





    # your other URL patterns
] 
