import os
import webbrowser

def open_pdf_from_output_folder(filename):
    # Construct the full path to the PDF file in the 'output' folder
    file_path = os.path.join('output', filename)
    
    # Check if the file exists and is a PDF
    if os.path.exists(file_path) and filename.lower().endswith('.pdf'):
        # Open the PDF file in the default web browser
        webbrowser.open_new_tab(f'file://{os.path.abspath(file_path)}')
        print(f"Opening {file_path} in the default web browser.")
    else:
        print(f"The file {file_path} does not exist or is not a PDF.")
        
open_pdf_from_output_folder('Gap_Summary1.pdf')