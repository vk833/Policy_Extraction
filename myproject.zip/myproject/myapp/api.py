# import requests
# import json
# import urllib3

# # Disable SSL warnings (only use in development, not recommended for production)
# urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# # API endpoint
# url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/c5f9ae69-685e-48f1-9958-5d44b5b92557/conversation"

# # Replace with your actual access token
# access_token = "eyJraWQiOiJndF94TUxSbTZiT3FwS1lCTWhQYkt2SGR6ZkJ4aVhIRWx0WjQ4MVhRTXRjIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULmpZMHIxZFI4Uk42V2F0b255clhOLUZlTHBxM1Z4Skk2MjU4REozQmRydlUiLCJpc3MiOiJodHRwczovL2FtZXhnYnQub2t0YS5jb20vb2F1dGgyL2RlZmF1bHQiLCJhdWQiOiJhcGk6Ly9kZWZhdWx0IiwiaWF0IjoxNzQ3MjM0ODEyLCJleHAiOjE3NDcyMzg0MTIsImNpZCI6IjBvYTIyY2Y2cW1paU5TSkNEMGg4Iiwic2NwIjpbImRlZmF1bHQiXSwic3ViIjoiMG9hMjJjZjZxbWlpTlNKQ0QwaDgifQ.Ihhh98DprXByGqANw3nDQxyMsxBN4Qwnw70mzWIS_jcZ_nln05HHtde-oSRgCy_7dNk9kzZZNn8bq63CzjoKNswI4o4fgkue_M55KNedLRCZEkr5rkKnOZkO0qHi3CQWImtrK18zKH8SpE8DHCcjgoUlyrXc0vtBJG3rizU2h9w075M5lvRjchkSGsrck8wkmGw_7e_YJadTK1v5gzYHa74rXIOg71f4i4EnAxPZ9Ah3fPIck_9G8N1AdbmbBSU6k0abSjY50ARBn-OdZUaSyJIX1i5MQX8JUSbj2W-qySafhmQdLuAgAytii17rsDjy42jmjgsL7u_IXJxRtpIRwg"

# # Headers
# headers = {
#     'Content-Type': 'application/json',
#     'X-Access-Token': access_token
# }

# # Payload
# data = {
#     "promptId": "030a86e1-ca63-4cd9-8901-27d869925bc7",
#     "messages": [],
#     "input": {
#         "input": "hi"
#     }
# }

# try:
#     response = requests.post(url, headers=headers, data=json.dumps(data), verify=False)

#     if response.status_code == 200:
#         print("✅ API call successful")
#         print(json.dumps(response.json(), indent=2))
#     else:
#         print(f"❌ API call failed with status code {response.status_code}")
#         print(response.text)

# except requests.exceptions.RequestException as e:
#     print("❗ An error occurred while making the API call:")
#     print(e)



# import requests
# # token=""
# # url = 'https://amexgbt.okta.com/oauth2/default/v1/token'
# # headers = {
# #     'Authorization': 'Basic MG9hMjJjZjZxbWlpTlNKQ0QwaDg6TlM5dHFtWmh2Nko0OXhhMmdmaHdhM29Md0RtLUlKdDYtNzduajRZbkZWM1hzTWl4Vi15eW5qeE1talJPaG0xNQ==',
# #     'Content-Type': 'application/x-www-form-urlencoded'
# # }
# # data = {
# #     'grant_type': 'client_credentials'
# # }

# # # Optional: Add proxy settings if required
# # # proxies = {
# # #     "http": "http://your.proxy.server:port",
# # #     "https": "http://your.proxy.server:port"
# # # }

# # response = requests.post(url, headers=headers, data=data)  # , proxies=proxies

# # if response.status_code == 200:
# #     token = response.json().get('access_token')
# #     print("Access Token:", token)
# # else:
# #     print("Failed to get token:", response.status_code, response.text)

import re
import random

# Define replacement rules with multiple options
replacements = {
    "bias": ["optimize"],
    "control": ["manage"],
    "leverage": ["optimize", "utilize"],
    "market": ["region", "country", "corporate travel industry", "corporate travel business"],
    "power": ["skill", "value", "efficiency", "capability"],
    "revenue synergy": ["cost synergy", "efficiencies"],
    "target": ["target", "goal"],
    "pinpoint": ["pinpoint"],
    "expert": ["professional", "specialist", "counselor", "experience"],
    "expertise": ["professional", "specialist", "counselor", "experience"],
    "subject-matter expert": ["professional", "specialist", "counselor", "experience"]
}

# Define banned words
banned_words = ["ensure", "insure", "guarantee"]

def clean_text(input_text):
    cleaned = input_text

    # Remove banned words
    for banned in banned_words:
        cleaned = re.sub(rf"(?i)\b{banned}\b", "", cleaned)

    # Replace restricted words with a random alternative
    for word, alternatives in replacements.items():
        cleaned = re.sub(rf"(?i)\b{word}\b", lambda match: random.choice(alternatives), cleaned)

    return cleaned

# Example usage
if __name__ == "__main__":
    sample_text = """
    Our team of subject-matter experts was assembled to leverage our control over the corporate travel market.
    We aim to ensure that our strategies are free from bias and deliver measurable revenue synergy.
    The power of our platform lies in its ability to pinpoint traveler preferences and adapt in real-time.
    We guarantee that our expertise will help you reach your target audience effectively.
    Whether you're entering a new market or optimizing an existing one, our professionals are here to help.
    We also insure that all data is handled with care and precision.
    """
    cleaned_text = clean_text(sample_text)
    print("Original Text:\n", sample_text)
    print("\nCleaned Text:\n", cleaned_text)
