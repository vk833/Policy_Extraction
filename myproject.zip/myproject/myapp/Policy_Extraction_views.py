import json
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
import zipfile

from django.conf import settings
from .forms import UploadFileForm
import os
import html
import asyncio
import aiohttp
import pandas as pd
from io import BytesIO, StringIO
from pdfminer.high_level import extract_text
from django.shortcuts import render, redirect
from django.http import FileResponse, HttpResponse, JsonResponse
from .forms import UploadFileForm
from pandas.errors import EmptyDataError
import requests
import warnings



warnings.filterwarnings("ignore", category=UserWarning, module="openpyxl")



try:
    token_response = requests.post(
        "https://amexgbt.okta.com/oauth2/default/v1/token",
        headers={
            "Authorization": "Basic MG9hMjJ3NHFqMWtyU3dPUDEwaDg6Q2t0cGZYS0RPdmprM1lDdVBmTVp0UkgtajhKMEs4Z1JWRy1mT2dQaG5Pb2ZJVE9lbldiY05BXy00cXhna1hkWQ==",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data="grant_type=client_credentials",
    )
    if token_response.status_code == 200:
        token = token_response.json().get("access_token")
    else:
        print("Failed to fetch token:", token_response.status_code, token_response.text)
except Exception as e:
    print("Token fetch failed:", e)
print("token is generated now",token)
count = ""


import os

def handle_uploaded_file(file, upload_dir):
    # Ensure only one file is in the upload directory
    for existing_file in os.listdir(upload_dir):
        file_path = os.path.join(upload_dir, existing_file)
        if os.path.isfile(file_path):
            os.remove(file_path)

    # Save the new file
    file_path = os.path.join(upload_dir, file.name)
    with open(file_path, "wb+") as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    return file_path



def is_two_column_band(chars, mid_x, threshold=0.2):
    if not chars:
        return False
    left_count = sum(1 for c in chars if c["x0"] < mid_x)
    right_count = sum(1 for c in chars if c["x0"] >= mid_x)
    if max(left_count, right_count) == 0:
        return False
    return min(left_count, right_count) / max(left_count, right_count) > threshold
import pdfplumber
def convert_pdf_to_text1(pdf_path, band_height=100, overlap=30):
    extracted_text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page_num, page in enumerate(pdf.pages, start=1):
            extracted_text += f"\n--- Page {page_num} ---\n"
            page_width = page.width
            page_height = page.height
            mid_x = page_width / 2

            y_top = 0
            while y_top < page_height:
                y_bottom = min(y_top + band_height, page_height)
                band = page.within_bbox((0, y_top, page_width, y_bottom))
                chars = band.chars

                if is_two_column_band(chars, mid_x):
                    left_text = page.within_bbox((0, y_top, mid_x, y_bottom)).extract_text() or ""
                    right_text = page.within_bbox((mid_x, y_top, page_width, y_bottom)).extract_text() or ""
                    extracted_text += left_text + "\n" + right_text + "\n"
                else:
                    full_text = band.extract_text() or ""
                    extracted_text += full_text + "\n"

                y_top += band_height - overlap

    return extracted_text

import re


async def process_category(
    session,
    category,
    count,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns,
    
):
    # print(count, " ", category)
    try:
        full_input = f"""
        This is a travel policy document (PDF1): {pdf_text}
        This is an Excel file (Excel1): {excel_text}

        Task: Process the category '{category}'.

        MANDATORY INSTRUCTIONS:
        - Do NOT skip any rows of category:{category}, even if the count is {count} ,i want all {count} in single response even length is big.
        - Process ALL entries for this category. 
        - Output MUST be a valid CSV with the following columns in this exact order:
        "Category", "Subcategory", "Primary Content", "Type", "Client Content", "Rating", "Points", "Maximum Score", "GBC BEST PRACTICE CONTENT"
        - Every row MUST contain values for "Category" and "Subcategory":
        - If missing, use the current category name for "Category".
        - do not skip "category" column content(values) for {category}
        - Infer "Subcategory" from context or leave as "General" if not available.
        - DO NOT allow any column displacement. Each value must stay in its correct column.
        - If any column contains commas, quotes, or line breaks, wrap the entire field in double quotes to preserve CSV structure.
        - Fix malformed rows caused by broken lines or misplaced commas.
        - DO NOT merge or duplicate columns.
        - DO NOT copy "GBC BEST PRACTICE CONTENT" into "Client Content".
        - "Client Content" must be detailed, accurate, and based on the policy document.
        - Compare "Client Content" with "GBC BEST PRACTICE CONTENT" and assign a rating: Full, Partial, or Null.
        - If "Type" is not blank, set "Maximum Score" to 0.
        - DO NOT include any explanation or text before or after the CSV.
        - Return ONLY the CSV content, clean and ready to be saved.
        ADDITIONAL INSTRUCTION FOR Data Integrity:
        -"Note: All input values are wrapped in double quotes. Do not displace or misaligned any column content."  
        - Ensure the category "{category}" is fully and accurately processed.
        - Do not omit any word, column, row, content, or value from the {category} Category. Every element present in the input—whether it is a column name, word, value, or cell—must also be present in the output.        
        - Every column and every row from the input Excel sheet related to this category must be included in the output.
        - Do NOT skip or omit any content from any column.
        - Each value from the input must be placed in its correct corresponding column in the output CSV.
        - Maintain the exact column structure and order as specified.
        - Do NOT merge, shift, or misplace any content across columns.
        - Pay special attention to preserving the integrity of each row’s data across all columns.        - Put GBC BEST PRACTICE CONTENT Content Into "".
        -I want 9 fields in output in all rows.


        IMPORTANT STRUCTURE VALIDATION:
        - Every row in the output MUST contain exactly 9 fields, matching the header structure.
        - If any row has fewer than 9 fields, fill missing values appropriately (e.g., use current category name for missing "Category").
        - If any row has more than 9 fields, remove excess values or merge them correctly to maintain structure.
        - DO NOT return any malformed rows. Every row must be clean, complete, and aligned with the header.
        - Validate the CSV before returning. If any row is malformed, fix it before including it in the output.


        ADDITIONAL INSTRUCTION FOR "Client Content":
        - For each row, extract or paraphrase all relevant and specific content from the travel policy document (PDF1) that corresponds to the "Primary Content" and "Category", "Subcategory".
        - Include every applicable point from the policy. Do NOT summarize or merge multiple points into one—list them all clearly and completely.
        - Ensure "Client Content" is not generic. It must reflect the actual language, rules, or procedures stated in the policy.
        - If the policy contains multiple relevant clauses, include each one in full or paraphrased form, separated clearly (e.g., with bullet points or line breaks).
        - Prioritize accuracy and completeness. Do not leave "Client Content" blank unless the policy has absolutely no relevant information.
        - Do NOT copy or reference "GBC BEST PRACTICE CONTENT" in this column.
        -Strictly Follow = Wrap the entire "Client Content" field in double single quotes ("") to prevent column displacement due to commas, line breaks, or special characters.
        - Do NOT skip any rows of category:{category}, even if the count is {count} ,i want all {count} in single response even length is big.
        - Do not skip any row of {category} there are {count} number of cells i want all cells in output.
        - if the information is not present in Policy so do not make or put related information just put "Not available in policy document".
        - If specific information is not explicitly mentioned in the policy document, do not infer or include related details. Instead, clearly state: 'Not available in policy document'.
important prompt
- Output MUST be a valid CSV with the following columns in this exact order...
- You MUST include the CSV header line exactly as specified, even if no data rows are present.
       
        """


        data = {
            "promptId": "58fc18e0-2ee3-46da-841e-2f494ffe2ce5",
            "messages": [],
            "input": {"input": full_input},
        }

        async with session.post(api_url, headers=headers, json=data, ssl=False) as resp:
            resp.raise_for_status()
            response_json = await resp.json()
            try:
                csv_string = response_json["data"]["messages"][0]["content"]
            except (KeyError, TypeError, IndexError) as e:
                raise ValueError(f"Failed to extract CSV content from response. Error: {e}\nRaw response: {response_json}")

           

            # Use regex to find the header line
            def find_csv_start(csv_string):
                for i, line in enumerate(csv_string.splitlines()):
                    # Remove quotes and normalize
                    cleaned_line = line.replace('"', '').strip().lower()
                    if cleaned_line.startswith("category,subcategory"):
                        return i
                return -1

            csv_lines = csv_string.splitlines()
            csv_start_index = find_csv_start(csv_string)

            if csv_start_index == -1:
                raise ValueError("CSV header not found in the response.")

            csv_data = '\n'.join(csv_lines[csv_start_index:])
            csv_data = (
                csv_data.replace('\\"', '"')
                        .replace("\\n", "\n")
                        .replace("_x000D_", "")
            )
            import csv
            from io import StringIO
            import pandas as pd

            expected_fields = 9
            category  # or use your dynamic category variable

            lines = csv_data.strip().split('\n')
            reader = csv.reader(lines)
            header = next(reader)
            cleaned_rows = [header]

            for row in reader:
                if len(row) == expected_fields:
                    cleaned_rows.append(row)
                elif len(row) == expected_fields - 1:
                    corrected_row = [category] + row
                    cleaned_rows.append(corrected_row)
                elif len(row) > expected_fields:
                    merged_last = ','.join(row[expected_fields - 1:])
                    trimmed_row = row[:expected_fields - 1] + [merged_last]
                    cleaned_rows.append(trimmed_row)

            output = StringIO()
            writer = csv.writer(output)
            writer.writerows(cleaned_rows)
            output.seek(0)

            df = pd.read_csv(output)


            df.columns = [col.strip() for col in df.columns]
            col_map = {col.lower(): col for col in df.columns}
            for expected in expected_columns:
                if expected not in df.columns:
                    match = col_map.get(expected.lower())
                    if match:
                        df.rename(columns={match: expected}, inplace=True)
                    else:
                        df[expected] = ""
            df = df[expected_columns]
            safe_filename = f"{category.replace(' ', '_')}.csv"
            df.to_csv(
                os.path.join(outputs_dir, safe_filename),
                index=False,
                encoding="utf-8",
                quoting=csv.QUOTE_ALL,
            )
            return f"Processed: {category}"

    except Exception as e:
        return f"Error processing category '{category}': {e}"


number = 10


async def process_all_categories(
    categories,
    category_counts,
    pdf_text,
    excel_text,
    api_url,
    headers,
    outputs_dir,
    expected_columns,
    
):
    excel_df = pd.read_json(StringIO(excel_text))

    async with aiohttp.ClientSession() as session:
        tasks = []

        for category in categories:
            count = category_counts[category]
            category_df = excel_df[excel_df["Category"] == category]

            if count > number:
                chunks = [
                    category_df.iloc[i : i + number] for i in range(0, count, number)
                ]
                for idx, chunk in enumerate(chunks, start=1):
                    chunk_text = chunk.to_json(index=False)
                    chunk_name = f"{category} - Part {idx}"
                    tasks.append(
                        process_category(
                            session,
                            chunk_name,
                            len(chunk),
                            pdf_text,
                            chunk_text,
                            api_url,
                            headers,
                            outputs_dir,
                            expected_columns,
                            
                        )
                    )
            else:
                chunk_text = category_df.to_json(index=False)
                tasks.append(
                    process_category(
                        session,
                        category,
                        count,
                        pdf_text,
                        chunk_text,
                        api_url,
                        headers,
                        outputs_dir,
                        expected_columns,
                        
                    )
                )

        return await asyncio.gather(*tasks)


input_dir = "input/"


def wrap_in_quotes(value):
    """Wrap the given value in double quotes."""
    return f'"{value}"'




def upload_files(request):
    if request.method == "POST":
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            pdf_file = request.FILES["pdf_file"]
            input_dir = "input/"
            csv_file_path = os.path.join(input_dir, "Template.xlsx")
            upload_dir = "uploads/"
            outputs_dir = "Outputs/"

            os.makedirs(upload_dir, exist_ok=True)
            os.makedirs(outputs_dir, exist_ok=True)

            pdf_file_path = handle_uploaded_file(pdf_file, upload_dir)
            pdf_text = convert_pdf_to_text1(pdf_file_path)

            try:
                excel_data = pd.read_excel(csv_file_path, engine="openpyxl")

                if "Category" not in excel_data.columns:
                    return HttpResponse(
                        "The Excel file must contain a 'Category' column.", status=400
                    )

                for col in excel_data.columns:
                    if col != "Category":
                        excel_data[col] = excel_data[col].map(wrap_in_quotes)

                category_counts = excel_data["Category"].value_counts().to_dict()
                unique_categories = list(category_counts.keys())
                excel_text = excel_data.to_json(index=False)

            except EmptyDataError:
                return HttpResponse(
                    "The uploaded Excel file is empty or invalid.", status=400
                )
            except Exception as e:
                return HttpResponse(
                    f"An error occurred while processing the Excel file: {e}",
                    status=500,
                )


            api_url = "https://prompt-studio.ai-studios.gbt.gbtad.com/api/v1/projects/ca99b671-639e-4612-8825-2b0b49cc958b/conversation"
            headers = {"Content-Type": "application/json", "X-Access-Token": token}

            expected_columns = [
                "Category",
                "Subcategory",
                "Primary Content",
                "Type",
                "Client Content",
                "Rating",
                "Points",
                "Maximum Score",
                "GBC BEST PRACTICE CONTENT",
            ]

            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                results = loop.run_until_complete(
                    process_all_categories(
                        unique_categories,
                        category_counts,
                        pdf_text,
                        excel_text,
                        api_url,
                        headers,
                        outputs_dir,
                        expected_columns,
                        
                    )
                )
                errors = [r for r in results if r.startswith("Error")]
                if errors:
                    return HttpResponse(
                        f"""
                        <script>
                        alert("{html.escape(str(errors))}");
                        window.history.back();
                        </script>
                    """
                    )
                preprocess_csv_files_For_PolicyExtraction()
                return redirect("/successful/?from=upload")
            except Exception as e:
                return HttpResponse(
                    f"""
                    <script>
                    alert("{html.escape(str(e))}");
                    window.history.back();
                    </script>
                """
                )
    else:
        form = UploadFileForm()
    return render(request, "myapp/upload.html", {"form": form})


from django.contrib import messages
from django.shortcuts import render


def successful_view(request):
    if request.GET.get("from") == "upload":
        messages.success(request, "✅ Successfully Completed")
    if request.GET.get("from") == "gap":
        messages.success(request, "✅ Successfully Completed")
    return render(request, "myapp/successful.html")


outputs_dir = "Outputs/"


def preprocess_csv_files_For_PolicyExtraction():
    output_dir = os.path.join(settings.BASE_DIR, "Outputs")
    input_dir = os.path.join(settings.BASE_DIR, "input")
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(input_dir, exist_ok=True)


    try:
        # Step 1: Combine files with similar base names (e.g., Part_1, Part_2)
        csv_files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
        file_groups = {}

        for file in csv_files:
            match = re.match(r"(.+?)_-_Part_\d+\.csv$", file)
            if match:
                base_name = match.group(1)
                file_groups.setdefault(base_name, []).append(file)

        for base, files in file_groups.items():
            dataframes = []
            for f in sorted(files):
                file_path = os.path.join(output_dir, f)
                try:
                    df = pd.read_csv(file_path)
                    if df.empty:
                        print(f"⚠️ Skipped empty file: {f}")
                    else:
                        dataframes.append(df)
                except Exception as e:
                    print(f"❌ Error reading file {f}: {e}")

            if dataframes:
                combined_df = pd.concat(dataframes, ignore_index=True)
                safe_base = re.sub(r'[\\/*?:"<>| ]+', "_", base).strip("_")
                combined_file_path = os.path.join(output_dir, f"{safe_base}.csv")
                combined_df.to_csv(combined_file_path, index=False)

                for f in files:
                    os.remove(os.path.join(output_dir, f))
            else:
                print(f"⚠️ No valid data to combine for: {base}")

        # Step 2: Combine Sustainability and Wellbeing if both exist
        sustainability_file = os.path.join(output_dir, "Sustainability.csv")
        wellbeing_file = os.path.join(output_dir, "Wellbeing.csv")

        if os.path.exists(sustainability_file) and os.path.exists(wellbeing_file):
            df_sustainability = pd.read_csv(sustainability_file)
            df_wellbeing = pd.read_csv(wellbeing_file)

            combined_df = pd.concat([df_sustainability, df_wellbeing], ignore_index=True)
            combined_file_path = os.path.join(output_dir, "Sustainability&Wellbeing.csv")
            combined_df.to_csv(combined_file_path, index=False)

            os.remove(sustainability_file)
            os.remove(wellbeing_file)

        # Step 3: Clean "Client Content" column
        for filename in os.listdir(output_dir):
            if filename.endswith(".csv"):
                file_path = os.path.join(output_dir, filename)
                df = pd.read_csv(file_path)

                if "Client Content" in df.columns:
                    df["Client Content"] = (
                        df["Client Content"]
                        .astype(str)
                        .apply(lambda x: x[1:-1] if x.startswith('"') and x.endswith('"') else x)
                    )
                    df.to_csv(file_path, index=False)
        # Step 4: Combine all CSV files into one master file and save to Inputs
        all_csv_files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
        master_dataframes = []

        for file in all_csv_files:
            file_path = os.path.join(output_dir, file)
            try:
                df = pd.read_csv(file_path)
                if not df.empty:
                    master_dataframes.append(df)
            except Exception as e:
                print(f"❌ Error reading file {file} for master merge: {e}")

        if master_dataframes:
            master_df = pd.concat(master_dataframes, ignore_index=True)
            master_file_path = os.path.join(input_dir, "All_Combined.xlsx")
            master_df.to_excel(master_file_path, index=False, engine='openpyxl')

    except Exception as e:
        return HttpResponse(f"Error processing files: {e}", status=500)


    except Exception as e:
        print(f"❌ Error during preprocessing: {e}")
def combine_and_list_csv_files(request, template_name="myapp/list_files.html"):
    output_dir = os.path.join(settings.BASE_DIR, "Outputs")
    input_dir = os.path.join(settings.BASE_DIR, "input")
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(input_dir, exist_ok=True)

    # Step 5: List final CSV files
    try:
        files = [f for f in os.listdir(output_dir) if f.endswith(".csv")]
    except FileNotFoundError:
        return HttpResponse("The Outputs folder was not found.", status=404)

    return render(request, template_name, {"files": files})




def view_csv_file(request, filename):
    file_path = os.path.join(outputs_dir, filename)
    csv_data = []

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                csv_data.append(row)
    except FileNotFoundError:
        return HttpResponse(f"The file {filename} was not found.", status=404)

    return render(
        request, "myapp/view_csv.html", {"csv_data": csv_data, "filename": filename}
    )




def list_csv_files_combined(request, template_name="myapp/list_files.html"):
    directory = "Outputs"
    try:
        files = [f for f in os.listdir(directory) if f.endswith(".csv")]
    except FileNotFoundError:
        return HttpResponse("The outputs folder was not found.", status=404)

    return render(request, template_name, {"files": files})


def download_csv(request):
    filename = request.GET.get("filename")
    if not filename:
        return HttpResponse("Filename not specified.", status=400)

    file_path = os.path.join("Outputs", filename)

    try:
        with open(file_path, "rb") as f:
            response = HttpResponse(f.read(), content_type="text/csv")
            response["Content-Disposition"] = f"attachment; filename={filename}"
            return response
    except FileNotFoundError:
        return HttpResponse(f"The file {filename} was not found.", status=404)





def download_all_csvs(request):
    directory = "Outputs"
    zip_buffer = BytesIO()

    with zipfile.ZipFile(zip_buffer, "w") as zip_file:
        for filename in os.listdir(directory):
            if filename.endswith(".csv"):
                file_path = os.path.join(directory, filename)
                zip_file.write(file_path, arcname=filename)

    zip_buffer.seek(0)
    response = HttpResponse(zip_buffer, content_type="application/zip")
    response["Content-Disposition"] = "attachment; filename=all_csv_files.zip"
    return response




def check_csv(request):
    output_dir = "Outputs/"
    has_csv = any(fname.endswith(".csv") for fname in os.listdir(output_dir))
    return JsonResponse({"has_csv": has_csv})




def combine_csvs_view(request):
    outputs_folder = "Outputs"
    output_file = "combined_sheets.xlsx"

    # List all CSV files in the Outputs folder
    csv_files = [f for f in os.listdir(outputs_folder) if f.endswith(".csv")]

    # Combine CSVs into Excel
    with pd.ExcelWriter(output_file, engine="xlsxwriter") as writer:
        for file in csv_files:
            file_path = os.path.join(outputs_folder, file)
            df = pd.read_csv(file_path)
            sheet_name = os.path.splitext(file)[0]
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    return FileResponse(
        open(output_file, "rb"), as_attachment=True, filename=output_file
    )
