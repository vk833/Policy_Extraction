# from django import forms

# class UploadFileForm(forms.Form):
#     pdf_file = forms.FileField()
#     csv_file = forms.FileField()


from django import forms

class UploadFileForm(forms.Form):
    pdf_file = forms.FileField(label='PDF File')

    
